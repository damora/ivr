var DataView = require('buffer-dataview');
var net = require('net');
var png = require('png-js');
var window = require('Base64');
var port = 5800;
var host = "9.2.132.200";

var off =  {
    data_fileindex: 0,
    wid_rounded_to_tile: 4,
    hgt_rounded_to_tile: 8,
    killswitch: 12,
    vpchange: 16,
    world_eye: 20,
    eye_latitude: 32,
    eye_longitude: 36,
    levelval: 40,
    center: 48,
    alpha_m: 60,
    alpha_e: 64,
    fovy: 68,
    view_clipplane: 72,
    display: 80,
    pointsize: 92,
    lighting_enabled: 96,
    auto_surface: 100,
    modelview_matrix: 104,
    projection_matrix: 168,
    cutplane: 232,
    deltasample: 256,
    cellsize: 260
};
var myimage = png.load('images/test.png');
var mypixels;

/*
png.decode('test.png', function(pixels) {
	mypixels = pixels;
});
var width  = myimage.width;
var height = myimage.height;
console.log("size="+width+","+height);
*/
var client = new net.Socket();
client.connect(port, host , function() {
	console.log('TCP  client connected....');
});
 
client.on('data', function(data) {

	console.log('RECVD:' + data.length);
	var s  = new DataView(data);

	console.log(s.getUint32(off.data_fileindex));
	console.log(s.getUint32(off.wid_rounded_to_tile));
	console.log(s.getUint32(off.hgt_rounded_to_tile));
	console.log(s.getUint32(off.killswitch));
	console.log(s.getUint32(off.vpchange));
	console.log(s.getFloat32(off.eye_latitude));
	console.log(s.getFloat32(off.eye_longitude));
	console.log(s.getFloat64(off.levelval));
	console.log(s.getFloat32(off.alpha_m));
	console.log(s.getFloat32(off.alpha_e));
	console.log(s.getFloat32(off.fovy));
	console.log(s.getUint32(off.pointsize));
	console.log(s.getUint32(off.lighting_enabled));
	console.log(s.getUint32(off.auto_surface));
	console.log(s.getFloat32(off.deltasample));
	console.log(s.getUint32(off.cellsize));

		
	///GOOD///client.write(myimage.data);
	//client.write(Buffer(mypixels));


	});
	 
	client.on('close', function() {
		client.destroy(); // kill client after server's response
		console.log('Connection closed');
	});

	function base64ToArrayBuffer(base64) {
		var binary_string =  window.atob(base64);
		var len = binary_string.length;
		console.log("len="+len);
		var bytes = new Uint8Array( len );
		for (var i = 0; i < len; i++)        {
			bytes[i] = binary_string.charCodeAt(i);
		}
		return bytes.buffer;
	}
