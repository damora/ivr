/*global $, jQuery, console, statedata */
function onoff(id){
  currentvalue = document.getElementById(id).value;
  if(currentvalue == "Off"){
    document.getElementById(id).value="On";
  }else{
    document.getElementById(id).value="Off";
  }
}


function slideinout(id) {
	slider.slideReveal(id);
}



    $(function(){
    	var slider = $("#sidebar").slideReveal({
        position: "left",
        push:   true,
        width: 250,
        top: 0,
        bottom: 0,
        autoescape: true,
        trigger: $(".handle"),
        shown: function(obj) {
            obj.find('.handle').html('<span class="glyphicon glyphicon-chevron-left"></span>');
        //  obj.addClass("left-shadow-overlay");
        },
        hidden: function(obj){
            obj.find('.handle').html('<span class="glyphicon glyphicon-chevron-right"></span>');
        //  obj.removeClass("left-shadow-overlay");
        },
    });
  });

  function updatevalue(val) {
    document.getElementById('textInput').value = val;
    console.log ("val= " + val);
  }

  function buttonselect(id) {
    if (document.getElementById(id).className != "selected")
        document.getElementById(id).className = "selected";
    else
        document.getElementById(id).className = "active";

	if (id == "bbox-button") clientstate.bbox ^= 1;
	if (id == "grid-button") clientstate.grid ^= 1;
	if (id == "asd-button") {///serverstate.auto_surface ^= 1;
		clientstate.auto_surface ^= 1;
		UP.setUint32(state.auto_surface, clientstate.auto_surface);
	}

	if (id == "light-button") {
		 clientstate.light ^= 1;
		 UP.setUint32(state.lighting_enabled, clientstate.light);
		 statechange = 1;
	}
	if (id == "animate-button") {
		 clientstate.animate ^= 1;
	}
	if (id == "exit-button") {
		clientstate.connected ^= 1;
		if (!clientstate.connected) {
			UP.setUint32(state.killswitch,1);
			statechange = 1;
			// kill client websocket
		}
		else {
			// connect to server
		}
	}
  }

  function buttonhighlight(id) {
    console.log(id + " highlighted");
  }

   $(function() {

   var sliderx = $('#cutplaneX').ionRangeSlider({
		type: "double",
		grid: true,
		min: -256,
		max: 256,
		from: -256,
		to: 256,
		step: 1
    });
   var slidery = $('#cutplaneY').ionRangeSlider({
		type: "double",
		grid: true,
		min: -256,
		max: 256,
		from: -256,
		to: 256,
		step: 1
   
    });
   var sliderz = $('#cutplaneZ').ionRangeSlider({
		type: "double",
		grid: true,
		min: -256,
		max: 256,
		from: -256,
		to: 256,
		step: 1
   
    });
   });
/*
   $(function() {
   		var slideralpha = $('#range-alpha').range({
        range: false,
        change:function(value){
            var textboxr = $('#display-alpha');
            textboxr.val(value);
			UP.setFloat32(state.alpha_m , value);
			statechange = 1;
        }
    });
    var textboxalpha = $('#display-alpha');
    textboxalpha.change(function() {
        var newval = $(this).val();
        slideralpha.range('value',0,newval);
		UP.setFloat32(state.alpha_m , newval);
		statechange = 1;
    });

   var slideralphae = $('#range-alphae').range({
        range: false,
        change:function(value){
            var textboxr = $('#display-alphae');
            textboxr.val(value);
			UP.setFloat32(state.alpha_e , value);
			statechange = 1;
        }
    });
    var textboxalphae = $('#display-alphae');
    textboxalphae.change(function() {
        var newval = $(this).val();
        slideralphae.range('value',0,newval);
		UP.setFloat32(state.alpha_e , newval);
		statechange = 1;
    });

   var sliderdeltasample = $('#range-deltasample').range({
        range: false,
        change:function(value){
            var textboxr = $('#display-deltasample');
            textboxr.val(value);
			var dens = 1.0/exp2(14.0 * value);
			UP.setFloat32(state.deltasample , dens);
			statechange = 1;
        }
    });
    var textboxdeltasample = $('#display-deltasample');
    textboxdeltasample.change(function() {
        var newval = $(this).val();
        sliderdeltasample.range('value',0,newval);
		var dens = 1.0/exp2(14.0 * newval);
		UP.setFloat32(state.deltasample , dens);
		statechange = 1;
    });

    var slidersize = $('#range-pointsize').range({
        range: false,
        change:function(value){
            var textboxr = $('#display-pointsize');
            textboxr.val(value);
			UP.setInt32(state.pointsize,value);
			statechange = 1;
        }
    });
    var textboxsize = $('#display-pointsize'); 
	textboxsize.change(function() { 
		var newval = $(this).val(); 
		slidersize.range('value',0,newval); 
		UP.setInt32(state.pointsize,value);
		statechange = 1;
    });

   var sliderlevel = $('#range-level').range({
        range: false,
        change:function(value){
            var textboxr = $('#display-level');
            textboxr.val(value);
			var logarithmic_colormap  = filesdv[DEFAULTIDX].getUint32(file.logarithmic_colormap);
			if (logarithmic_colormap) { 
         		var temp_int = (value * 4095.99) << 20; 
				UP.setFloat64(state.levelval, temp_int);
      		} 
      		else { 
				var maxval = filesdv[DEFAULTIDX].getFloat32(file.processed_maxval);
				var minval = filesdv[DEFAULTIDX].getFloat32(file.processed_minval);
				var span = maxval-minval;
				UP.setFloat64(state.levelval, value * span);
      		} 
			statechange = 1;
        }
    });
    var textboxlevel = $('#display-level');
    textboxlevel.change(function() {
        var newval = $(this).val();
        sliderlevel.range('value',0,newval);
		var logarithmic_colormap  = filesdv[DEFAULTIDX].getUint32(file.logarithmic_colormap);
		if (logarithmic_colormap) { 
       		var temp_int = (value * 4095.99) << 20; 
			UP.setFloat64(state.levelval, temp_int);
   		} 
   		else { 
			var maxval = filesdv[DEFAULTIDX].getFloat32(file.processed_maxval);
			var minval = filesdv[DEFAULTIDX].getFloat32(file.processed_minval);
			var span = maxval-minval;
			UP.setFloat64(state.levelval, value * span);
		}
		statechange = 1;
    });
   var slidertimestep = $('#range-timestep').range({
        range: false,
        change:function(value){
            var textboxr = $('#display-timestep');
            textboxr.val(value);
			statechange = 1;
        }
    });
    var textboxtimestep = $('#display-timestep');
    textboxtimestep.change(function() {
        var newval = $(this).val();
        slidertimestep.range('value',0,newval);
		statechange = 1;
    });
});
*/

