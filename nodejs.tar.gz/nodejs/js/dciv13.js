/*global $, jQuery, console */
var globalcnt = 0;
var cond0 = 0;
var cond1 = 0;
var LEFT_BUTTON = 0;
var MIDDLE_BUTTON = 1;
var RIGHT_BUTTON = 2;
var first = true;
var requestid;
var sendcnt = 0;
var gl;
var text;
var textwidth, textheight;
var winleft, winright, wintop, winbottom;
var width, height;
var EDGEFRACTION = 0.2;
var ntiles_x;
var ntiles_y;
var ntiles;
var deltaX = 0, deltaY = 0;
var vwid, vhgt;
var fovy;
var scale = 1.0;
var up = new Float32Array(3);
var eye = new Float32Array(3);
var center = new Float32Array(3);
var unit_lookat = new Float32Array(3);
var eye_latitude;
var eye_longitude;
var wid_rnd_tile;
var hgt_rnd_tile;
var xorg, yorg;
var nearclip;
var farclip;
var z_up;
var nulltiles = [];
var tiles = [];
var tileidx = 0;
var serverneedsupdate = true;
var clientrecvdtiles = 0;
var textures = [];
var images = [];
var timestep = 0;
var animslice = [];
var n_timesteps_read = 1;
var FRONT, BACK, TOP, BOTTOM, RIGHT, LEFT;
var lastscale;
var lasteye = [];
var lastup = [];
var lastcenter = [];
var SP = matrix(2, 3, 0.0);
var SP1 = [], SP2 = [], SP3 = [], SP4 = [];
var SP_valid = [0, 0, 0];
var select_state = 0;
var select_x = 0, select_y = 0;
var selected_medium = 0;
 	function matrix (numrows, numcols, initial){
   		var arr = [];
   		for (var i = 0; i < numrows; ++i){
           var columns = [];
           for (var j = 0; j < numcols; ++j){
              columns[j] = initial;
           }
           arr[i] = columns;
        }
        return arr;
    }

	function encode (input) {
		var keyStr = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";
		var output = "";
		var chr1, chr2, chr3, enc1, enc2, enc3, enc4;
		var i = 0;

		while (i < input.length) {
      		chr1 = input[i++];
      		chr2 = i < input.length ? input[i++] : Number.NaN; // Not sure if the index
      		chr3 = i < input.length ? input[i++] : Number.NaN; // checks are needed here

      		enc1 = chr1 >> 2;
      		enc2 = ((chr1 & 3) << 4) | (chr2 >> 4);
      		enc3 = ((chr2 & 15) << 2) | (chr3 >> 6);
      		enc4 = chr3 & 63;

      		if (isNaN(chr2)) {
         		enc3 =  enc4 = 64;
      		} else if (isNaN(chr3)) {
         		enc4 = 64;
      		}
      		output += keyStr.charAt(enc1) + keyStr.charAt(enc2) +
                		keyStr.charAt(enc3) + keyStr.charAt(enc4);
		 }
		return output;
	}


    function initGL(canvas) {

        try {
 
            gl = canvas.getContext("webgl", {
				preserveDrawingBuffer: true,
				});

  			// Lookup the size the browser is displaying the canvas.
		  	width  = canvas.clientWidth;
			height = canvas.clientHeight;

 
  			// Check if the canvas is not the same size.
			if (canvas.width  != width ||
				canvas.height != height) {
 
    			// Make the canvas the same size
				canvas.width  = width;
				canvas.height = height;
			}
			// round to nearest multiple of tile size in both window directions
			UP.setUint32(state.wid_rounded_to_tile, ((width >> LOG2_TILE_X) << LOG2_TILE_X));
			UP.setUint32(state.hgt_rounded_to_tile, ((height >> LOG2_TILE_Y) << LOG2_TILE_Y));
			wid_rnd_tile = UP.getUint32(state.wid_rounded_to_tile);
			hgt_rnd_tile = UP.getUint32(state.hgt_rounded_to_tile);

			// compute number of tiles to cover screen
			ntiles_x = wid_rnd_tile >> LOG2_TILE_Y;
			ntiles_y = hgt_rnd_tile >> LOG2_TILE_Y;
			ntiles = ntiles_x * ntiles_y;


		    // all the tile images coming from isoparm_Server will be stored in this array	
			nulltiles = new Array(ntiles);
			tiles = new Array(ntiles);
			textures = new Array(ntiles);
            images = new Array(ntiles);
			
			for (var i=0; i<ntiles; i++) {
				nulltiles[i] = -1;
			}


			// udpates for tile projection
			var aspect = hgt_rnd_tile/wid_rnd_tile;
			vwid = wid_rnd_tile;
			vhgt = vwid*aspect;
			xorg = (width - vwid)/2;	
			yorg = (height - vhgt)/2;	
			gl.viewport(xorg, yorg, vwid-1, vhgt-1);

 // temp debug
/*
       gl.enable(gl.SCISSOR_TEST);
       gl.scissor(0,0, width-1, height-1);
       gl.clearColor(0.0, 1.0, 1.0, 1.0);
       gl.clear(gl.COLOR_BUFFER_BIT);
 
       gl.scissor(xorg, yorg, vwid-1, vhgt-1);
       gl.clearColor(1.0, 0.0, 0.0, 1.0);
       gl.clear(gl.COLOR_BUFFER_BIT);
       gl.disable(gl.SCISSOR_TEST);
 
   console.log("start\n");
   console.log("xorg=%d, yorg=%d, vwid=%d, vhgt=%d\n", xorg, yorg, vwid, vhgt)
   console.log("width=%d, height=%d\n", width, height)
   console.log("window.innerWidth=%d, window.innerHeight=%d\n", window.innerWidth, window.innerHeight);
   console.log("end\n");
*/
 //temp debug


        } catch (e) {
			console.log("Error in initGL");
        }
        if (!gl) {
            alert("Could not initialise WebGL, sorry :-(");
            console.log("Could not initialise WebGL, sorry :-(");
        }


		if ((filesdv[clientstate.fileidx].getUint32(file.n_timesteps) > 1)) {
			timestep = 1;
			clientstate.animate = 1;
		}
    }

	function initTextures() {
		gl.activeTexture(gl.TEXTURE0);
        for (var i=0; i<ntiles; i++) {
            textures[i] = gl.createTexture();
		}
	}

    function getShader(gl, id) {
        var shaderScript = document.getElementById(id);
        if (!shaderScript) {
            return null;
        }

        var str = "";
        var k = shaderScript.firstChild;
        while (k) {
            if (k.nodeType == 3) {
                str += k.textContent;
            }
            k = k.nextSibling;
        }

        var shader;
        if (shaderScript.type == "x-shader/x-fragment") {
            shader = gl.createShader(gl.FRAGMENT_SHADER);
        } else if (shaderScript.type == "x-shader/x-vertex") {
            shader = gl.createShader(gl.VERTEX_SHADER);
        } else {
            return null;
        }

        gl.shaderSource(shader, str);
        gl.compileShader(shader);

        if (!gl.getShaderParameter(shader, gl.COMPILE_STATUS)) {
            alert(gl.getShaderInfoLog(shader));
            return null;
        }

        return shader;
    }

	function logelements(array, num) {
		console.log(array[0] + " " + array[1] + " " + array[2] +" " +  array[3]);
		console.log(array[4] + " " + array[5] + " " + array[6] +" " +  array[7]);
		console.log(array[8] + " " + array[9] + " " + array[10] +" " +  array[11]);
		console.log(array[12] + " " + array[13] + " " + array[14] +" " +  array[15]);
	}
	function initCamera() {

		trace("initCamera");

        // round to nearest multiple of tile size in both window directions
        UP.setUint32(state.wid_rounded_to_tile, ((width >> LOG2_TILE_X) << LOG2_TILE_X));
        UP.setUint32(state.hgt_rounded_to_tile, ((height >> LOG2_TILE_Y) << LOG2_TILE_Y));
        wid_rnd_tile = UP.getUint32(state.wid_rounded_to_tile);
        hgt_rnd_tile = UP.getUint32(state.hgt_rounded_to_tile);

        // udpates for tile projection
		var aspect = hgt_rnd_tile/wid_rnd_tile;
		vwid = wid_rnd_tile;
		vhgt = vwid*aspect;
		xorg = (width - vwid)/2;	
		yorg = (height - vhgt)/2;	
		gl.viewport(xorg, yorg, vwid-1, vhgt-1);
	    
		// Camera for bounding box
		gl.useProgram(shaderProgram);
        // update the serverstate projection matrix
		fovy = UP.getFloat32(state.fovy);
		nearclip = filesdv[clientstate.fileidx].getFloat32(file.near_clip_plane);
		farclip = filesdv[clientstate.fileidx].getFloat32(file.far_clip_plane);

        mat4.perspective(fovy, wid_rnd_tile/hgt_rnd_tile, nearclip, farclip, pMatrix);
		updateProjection(pMatrix);

		z_up = filesdv[clientstate.fileidx].getUint32(file.z_up);
		center[0] = UP.getFloat32(state.center);
		center[1] = UP.getFloat32(state.center+4);
		center[2] = UP.getFloat32(state.center+8);
		eye_longitude = 3.14 + 1.45;
		eye_latitude = 0.35;
		var slat = Math.sin(eye_latitude);
   		var clat = Math.cos(eye_latitude);
   		var slon = Math.sin(eye_longitude);
   		var clon = Math.cos(eye_longitude);
		if (z_up) {
			up[0] = 0.0; up[1] = 0.0; up[2] = 1.0;
			unit_lookat[0] = -(clat * clon);
      		unit_lookat[1] = -(clat * slon);
      		unit_lookat[2] = -(slat);
		}
		else {
			up[0] = 0.0; up[1] = 1.0; up[2] = 0.0;
			unit_lookat[2] = -(clat * clon);
      		unit_lookat[0] = -(clat * slon);
      		unit_lookat[1] = -(slat);
		}
		var dist_to_eye = filesdv[clientstate.fileidx].getFloat32(file.distance_to_eye);
		eye[0] = -unit_lookat[0] * dist_to_eye;
		eye[1] = -unit_lookat[1] * dist_to_eye;
		eye[2] = -unit_lookat[2] * dist_to_eye;

	}


    var shaderProgram;
    var tileshaderProgram;
    function initShaders() {
        var fragmentShader = getShader(gl, "shader-fs");
        var vertexShader = getShader(gl, "shader-vs");
		var tilefragmentShader = getShader(gl, "tile-shader-fs");
		var tilevertexShader = getShader(gl, "tile-shader-vs");

        shaderProgram = gl.createProgram();
        gl.attachShader(shaderProgram, vertexShader);
        gl.attachShader(shaderProgram, fragmentShader);
        gl.linkProgram(shaderProgram);
        if (!gl.getProgramParameter(shaderProgram, gl.LINK_STATUS)) {
            alert("Could not initialise shaders");
        }

		tileshaderProgram = gl.createProgram();
		gl.attachShader(tileshaderProgram, tilevertexShader);
		gl.attachShader(tileshaderProgram, tilefragmentShader);
		gl.linkProgram(tileshaderProgram);
        if (!gl.getProgramParameter(tileshaderProgram, gl.LINK_STATUS)) {
            alert("Could not initialise tile shaders");
        }

        gl.useProgram(shaderProgram);
        shaderProgram.vertexPositionAttribute = gl.getAttribLocation(shaderProgram, "aVertexPosition");
        gl.enableVertexAttribArray(shaderProgram.vertexPositionAttribute);
        shaderProgram.pMatrixUniform = gl.getUniformLocation(shaderProgram, "uPMatrix");
        shaderProgram.mvMatrixUniform = gl.getUniformLocation(shaderProgram, "uMVMatrix");

        gl.useProgram(tileshaderProgram);
        tileshaderProgram.vertexPositionAttribute = gl.getAttribLocation(tileshaderProgram, "aVertexPosition");
        gl.enableVertexAttribArray(tileshaderProgram.vertexPositionAttribute);
        tileshaderProgram.vertexTextureAttribute = gl.getAttribLocation(tileshaderProgram, "aTextureCoord");
        gl.enableVertexAttribArray(tileshaderProgram.vertexTextureAttribute);

        tileshaderProgram.pMatrixUniform = gl.getUniformLocation(tileshaderProgram, "uPMatrix");
        tileshaderProgram.mvMatrixUniform = gl.getUniformLocation(tileshaderProgram, "uMVMatrix");
    }

    function loadTexture(indx, tex, img ) {
        gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, true);
        gl.bindTexture(gl.TEXTURE_2D, tex);
        gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, img);
		gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
		gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
		gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE); //Prevents s-coordinate wrapping (repeating).
		gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE); //Prevents t-coordinate wrapping (repeating).

		if (!gl.isTexture(tex)) {
			console.error("Error: Texture is invalid");
		}
		//drawTile(indx);
        gl.bindTexture(gl.TEXTURE_2D, null);
    }


    var mvMatrix = mat4.create();
    var mvMatrixStack = [];
    var pMatrixStack = [];
    var pMatrix = mat4.create();
	var mvMat;
	var pMat;
    function mvPushMatrix() {
        var copy = mat4.create();
        mat4.set(mvMatrix, copy);
        mvMatrixStack.push(copy);
    }

    function mvPopMatrix() {
        if (mvMatrixStack.length === 0) {
            throw "Invalid popMatrix!";
        }
        mvMatrix = mvMatrixStack.pop();
    }
    function pPushMatrix() {
        var copy = mat4.create();
        mat4.set(pMatrix, copy);
        pMatrixStack.push(copy);
    }

    function pPopMatrix() {
        if (pMatrixStack.length === 0) {
            throw "Invalid popMatrix!";
        }
        pMatrix = pMatrixStack.pop();
    }

    function setMatrixUniforms(currentShader) {
        gl.uniformMatrix4fv(currentShader.pMatrixUniform, false, pMatrix);
        gl.uniformMatrix4fv(currentShader.mvMatrixUniform, false, mvMatrix);

       // var normalMatrix = mat3.create();
       // mat4.toInverseMat3(mvMatrix, normalMatrix);
       // mat3.transpose(normalMatrix);
      //  	gl.uniformMatrix3fv(shaderProgram.nMatrixUniform, false, normalMatrix);
    }


    function degToRad(degrees) {
        return degrees * Math.PI / 180;
    }

	function computelookAt()
	{
		eye_latitude  += degToRad((deltaY) / 10);
		eye_longitude += degToRad((deltaX) / 10);
		if (eye_latitude  >  3.141592) { eye_latitude  -= 2.0 * 3.141592; }
		if (eye_latitude  < -3.141592) { eye_latitude  += 2.0 * 3.141592; }
		if (eye_longitude >  3.141592) { eye_longitude -= 2.0 * 3.141592; }
		if (eye_longitude < -3.141592) { eye_longitude += 2.0 * 3.141592; }
		var work_longitude = eye_longitude;
		if (eye_latitude > ( 3.141592 / 2.0)) work_longitude += 3.141592;
		if (eye_latitude < (-3.141592 / 2.0)) work_longitude += 3.141592;
		if (work_longitude >  3.141592) { work_longitude -= 2.0 * 3.141592; }
		if (work_longitude < -3.141592) { work_longitude += 2.0 * 3.141592; }
						
		var slat = Math.sin(eye_latitude);
		var clat = Math.cos(eye_latitude);
		var slon = Math.sin(work_longitude);
		var clon = Math.cos(work_longitude);
		if (z_up) {
			up[0] = 0.0; up[1] = 0.0; up[2] = 1.0;
			unit_lookat[0] = -(clat * clon);
			unit_lookat[1] = -(clat * slon);
			unit_lookat[2] = -(slat);
		}
		else {
			up[0] = 0.0; up[1] = 1.0; up[2] = 0.0;
			unit_lookat[2] = -(clat * clon);
			unit_lookat[0] = -(clat * slon);
			unit_lookat[1] = -(slat);
		}
		var dist_to_eye = filesdv[clientstate.fileidx].getFloat32(file.distance_to_eye);
		eye[0] = -unit_lookat[0] * dist_to_eye;
		eye[1] = -unit_lookat[1] * dist_to_eye;
		eye[2] = -unit_lookat[2] * dist_to_eye;
	}

	function compute_select_points(ep0, ep1,  x,  y) {
   		var  upvector = [], screen_right = [], screen_up = [], tx= [], ty=[], tz=[], tlo, thi;
   		var  basis_vector = [], world_eye = [], resolved_eye = [], ray = [];
		var distance_to_eye = filesdv[FPP[0]].getFloat32(file.distance_to_eye);
   		world_eye[0] = UP.getFloat32(state.modelview_matrix+8) * distance_to_eye;
   		world_eye[1] = UP.getFloat32(state.modelview_matrix+24) * distance_to_eye;
   		world_eye[2] = UP.getFloat32(state.modelview_matrix+40) * distance_to_eye;
   		resolved_eye[0] = world_eye[0] + UP.getFloat32(state.center);
   		resolved_eye[1] = world_eye[1] + UP.getFloat32(state.center+4);
   		resolved_eye[2] = world_eye[2] + UP.getFloat32(state.center+8);

   		var world_extents = matrix(2,3,0.0);
		var half_xdim = filesdv[FPP[0]].getFloat32(file.half_xdim);
		var half_ydim = filesdv[FPP[0]].getFloat32(file.half_ydim);
		var half_zdim = filesdv[FPP[0]].getFloat32(file.half_zdim);
   		world_extents[0][0] = -half_xdim + 1.0;
   		world_extents[1][0] =  half_xdim - 1.0;
   		world_extents[0][1] = -half_ydim + 1.0;
   		world_extents[1][1] =  half_ydim - 1.0;
		if (FLIPZ) {
   			world_extents[0][2] = half_zdim * num_media - 1.0;
   			world_extents[1][2] = -half_zdim * num_media + 1.0;	
		}
		else {
   			world_extents[0][2] = -half_zdim * num_media + 1.0;
   			world_extents[1][2] = half_zdim * num_media - 1.0;
		}

   		var resolved_world_extents = matrix(2, 3, 0.0);
		var cutplane =  matrix(3, 2, 0.0);
		cutplane[0][0] = UP.getFloat32(state.cutplane);
		cutplane[0][1] = UP.getFloat32(state.cutplane + 4);
		cutplane[1][0] = UP.getFloat32(state.cutplane + 8);
		cutplane[1][1] = UP.getFloat32(state.cutplane + 12);
		cutplane[2][0] = UP.getFloat32(state.cutplane + 16);
		cutplane[2][1] = UP.getFloat32(state.cutplane + 20);
		
		if (FLIPZ) {
   			resolved_world_extents[0][0] = (cutplane[0][0] > world_extents[0][0]) ? cutplane[0][0] : world_extents[0][0];
   			resolved_world_extents[0][1] = (cutplane[1][0] > world_extents[0][1]) ? cutplane[1][0] : world_extents[0][1];
   			resolved_world_extents[0][2] = (cutplane[2][0] < world_extents[0][2]) ? cutplane[2][0] : world_extents[0][2];
   			resolved_world_extents[1][0] = (cutplane[0][1] < world_extents[1][0]) ? cutplane[0][1] : world_extents[1][0];
   			resolved_world_extents[1][1] = (cutplane[1][1] < world_extents[1][1]) ? cutplane[1][1] : world_extents[1][1];
   			resolved_world_extents[1][2] = (cutplane[2][1] > world_extents[1][2]) ? cutplane[2][1] : world_extents[1][2];
		}
		else {
   			resolved_world_extents[0][0] = (cutplane[0][0] > world_extents[0][0]) ? cutplane[0][0] : world_extents[0][0];
   			resolved_world_extents[0][1] = (cutplane[1][0] > world_extents[0][1]) ? cutplane[1][0] : world_extents[0][1];
   			resolved_world_extents[0][2] = (cutplane[2][0] > world_extents[0][2]) ? cutplane[2][0] : world_extents[0][2];
   			resolved_world_extents[1][0] = (cutplane[0][1] < world_extents[1][0]) ? cutplane[0][1] : world_extents[1][0];
   			resolved_world_extents[1][1] = (cutplane[1][1] < world_extents[1][1]) ? cutplane[1][1] : world_extents[1][1];
   			resolved_world_extents[1][2] = (cutplane[2][1] < world_extents[1][2]) ? cutplane[2][1] : world_extents[1][2];
		}
   		var  yz = (filesdv[FPP[0]].getInt32(file.z_up) === 1) ? 2 : 1;
   		resolved_world_extents[0][yz] *= UP.getFloat32(state.zscale);
   		resolved_world_extents[1][yz] *= UP.getFloat32(state.zscale);

   		var pme = [];
   		pme[0] = resolved_world_extents[0][0] - resolved_eye[0];
   		pme[1] = resolved_world_extents[0][1] - resolved_eye[1];
   		pme[2] = resolved_world_extents[0][2] - resolved_eye[2];
   		pme[3] = resolved_world_extents[1][0] - resolved_eye[0];
   		pme[4] = resolved_world_extents[1][1] - resolved_eye[1];
   		pme[5] = resolved_world_extents[1][2] - resolved_eye[2];

   		if (filesdv[FPP[0]].getInt32(file.z_up)) {
      		upvector[0] = 0.0; upvector[1] = 0.0; upvector[2] = 1.0;
   		}
   		else {
      		upvector[0] = 0.0; upvector[1] = 1.0; upvector[2] = 0.0;
   		}

		var mvm2, mvm6, mvm10;
		mvm2 = UP.getFloat32(state.modelview_matrix+8);
		mvm6 = UP.getFloat32(state.modelview_matrix+24);
		mvm10 = UP.getFloat32(state.modelview_matrix+40);

   		screen_right[0] = -mvm6 * upvector[2] - (-mvm10) * upvector[1];
   		screen_right[1] = -mvm10 * upvector[0] - (-mvm2) * upvector[2];
   		screen_right[2] = -mvm2 * upvector[1] - (-mvm6) * upvector[0];

   		var tmpinvlen = 1.0 / Math.sqrt(screen_right[0] * screen_right[0] + screen_right[1] * screen_right[1] + screen_right[2] * screen_right[2]);

   		screen_right[0] *= tmpinvlen;
   		screen_right[1] *= tmpinvlen;
   		screen_right[2] *= tmpinvlen;

   		screen_up[0] =  screen_right[1] * (-mvm10) - screen_right[2] * (-mvm6);
   		screen_up[1] =  screen_right[2] * (-mvm2) - screen_right[0] * (-mvm10);
   		screen_up[2] =  screen_right[0] * (-mvm6) - screen_right[1] * (-mvm2);

   		var tanval =  Math.tan((0.5 * UP.getFloat32(state.fovy)) * 3.1415926535898 / 180.0);
   		screen_up[0] *= tanval;
   		screen_up[1] *= tanval;
   		screen_up[2] *= tanval;
   		screen_right[0] *= tanval;
   		screen_right[1] *= tanval;
   		screen_right[2] *= tanval;

   		// now, make them all scaled to the distance from the eye to the origin:
   		screen_up[0] *= distance_to_eye;
   		screen_up[1] *= distance_to_eye;
   		screen_up[2] *= distance_to_eye;
   		screen_right[0] *= distance_to_eye;
   		screen_right[1] *= distance_to_eye;
   		screen_right[2] *= distance_to_eye;

		var wid_rounded_to_tile = UP.getUint32(state.wid_rounded_to_tile);
		var hgt_rounded_to_tile = UP.getUint32(state.hgt_rounded_to_tile);
   		// to make it a "pixel-sized delta" divide by half the height
   		screen_up[0] /= (0.5 * hgt_rounded_to_tile);
   		screen_up[1] /= (0.5 * hgt_rounded_to_tile);
   		screen_up[2] /= (0.5 * hgt_rounded_to_tile);
   		screen_right[0] /= (0.5 * hgt_rounded_to_tile);
   		screen_right[1] /= (0.5 * hgt_rounded_to_tile);
   		screen_right[2] /= (0.5 * hgt_rounded_to_tile);

   		// figure the vector to the lower-left corner of the screen, whose length extends from the eye to the plane through the origin normal to the eye vector.
   		basis_vector[0] = (-(world_eye[0])) + (-screen_right[0] * 0.5 * (wid_rounded_to_tile)) + (-screen_up[0] * 0.5 * (hgt_rounded_to_tile));
   		basis_vector[1] = (-(world_eye[1])) + (-screen_right[1] * 0.5 * (wid_rounded_to_tile)) + (-screen_up[1] * 0.5 * (hgt_rounded_to_tile));
   		basis_vector[2] = (-(world_eye[2])) + (-screen_right[2] * 0.5 * (wid_rounded_to_tile)) + (-screen_up[2] * 0.5 * (hgt_rounded_to_tile));

   		ray[0] = basis_vector[0] + screen_right[0] * (x + 0.5) + screen_up[0] * (y + 0.5);
   		ray[1] = basis_vector[1] + screen_right[1] * (x + 0.5) + screen_up[1] * (y + 0.5);
   		ray[2] = basis_vector[2] + screen_right[2] * (x + 0.5) + screen_up[2] * (y + 0.5);
   		tx[0] = pme[0] / ray[0];
   		tx[1] = pme[3] / ray[0];
   		if (tx[0] > tx[1]) { var temp = tx[0]; tx[0] = tx[1]; tx[1] = temp; }
   		ty[0] = pme[1] / ray[1];
   		ty[1] = pme[4] / ray[1];
   		if (ty[0] > ty[1]) { var temp = ty[0]; ty[0] = ty[1]; ty[1] = temp; }
   		tz[0] = pme[2] / ray[2];
   		tz[1] = pme[5] / ray[2];
   		if (tz[0] > tz[1]) { var temp = tz[0]; tz[0] = tz[1]; tz[1] = temp; }

   		tlo = tx[0];
   		thi = tx[1];
   		tlo = (tlo < ty[0]) ? ty[0] : tlo;
   		thi = (thi > ty[1]) ? ty[1] : thi;
   		tlo = (tlo < tz[0]) ? tz[0] : tlo;
   		thi = (thi > tz[1]) ? tz[1] : thi;
   		var t_clip0 = UP.getFloat32(state.view_clipplane) / distance_to_eye;
   		var t_clip1 = UP.getFloat32(state.view_clipplane+4) / distance_to_eye;
   		tlo = (tlo < t_clip0) ? t_clip0 : tlo;
   		thi = (thi < t_clip0) ? t_clip0 : thi;
   		tlo = (tlo > t_clip1) ? t_clip1 : tlo;
   		thi = (thi > t_clip1) ? t_clip1 : thi;
   		ep0[0] = world_eye[0] + tlo * ray[0];
   		ep0[1] = world_eye[1] + tlo * ray[1];
   		ep0[2] = world_eye[2] + tlo * ray[2];
   		ep1[0] = world_eye[0] + thi * ray[0];
   		ep1[1] = world_eye[1] + thi * ray[1];
   		ep1[2] = world_eye[2] + thi * ray[2];

   		/* undo the effects of scaling */
   		ep0[yz] /= UP.getFloat32(state.zscale);
   		ep1[yz] /= UP.getFloat32(state.zscale);
	}

	function find_skew_intersection(A, B, C, D, NP) {
		var  BAB, BAD, BCD, DCD, CAB, CAD, denom, numt0, nums0, t0, s0;

		BAB = B[0]*B[0]+B[1]*B[1]+B[2]*B[2] - (A[0]*B[0]+A[1]*B[1]+A[2]*B[2]);
		BAD = B[0]*D[0]+B[1]*D[1]+B[2]*D[2] - (A[0]*D[0]+A[1]*D[1]+A[2]*D[2]);
		BCD = B[0]*D[0]+B[1]*D[1]+B[2]*D[2] - (C[0]*B[0]+C[1]*B[1]+C[2]*B[2]);
		DCD = D[0]*D[0]+D[1]*D[1]+D[2]*D[2] - (C[0]*D[0]+C[1]*D[1]+C[2]*D[2]);
		CAB = C[0]*B[0]+C[1]*B[1]+C[2]*B[2] - (A[0]*B[0]+A[1]*B[1]+A[2]*B[2]);
		CAD = C[0]*D[0]+C[1]*D[1]+C[2]*D[2] - (A[0]*D[0]+A[1]*D[1]+A[2]*D[2]);

		// BAB * t0 - BCD * s0 = CAB
		// BAD * t0 - DCD * s0 = CAD

		denom = BAD * BCD - BAB * DCD;
		numt0 = CAD * BCD - CAB * DCD;
		nums0 = CAD * BAB - CAB * BAD;
		t0 = numt0 / denom;
		s0 = nums0 / denom;

		NP[0] = 0.5 * (A[0] + t0 * (B[0]-A[0]) + C[0] + s0 * (D[0]-C[0]));
		NP[1] = 0.5 * (A[1] + t0 * (B[1]-A[1]) + C[1] + s0 * (D[1]-C[1]));
		NP[2] = 0.5 * (A[2] + t0 * (B[2]-A[2]) + C[2] + s0 * (D[2]-C[2]));
	}


	function select_point(motion_flag, select_flag, x, y) {
		retval = 0;
		var select_target = UP.getUint32(state.select_target);
	    if (select_flag && (surface_select_flag == 0)) {
			 ++select_state;
			 if (select_state == 1) {
				compute_select_points(SP1, SP2, x-xorg, (hgt_rnd_tile-1) - (y-yorg));
			 }
			 else if (select_state == 3) {
				compute_select_points(SP3, SP4, x-xorg, (hgt_rnd_tile-1) - (y-yorg));
				find_skew_intersection(SP1, SP2, SP3, SP4, SP[select_target]);
				SP_valid[select_target] = 1;
			 }
			 select_x = x-xorg;
			 select_y = (hgt_rnd_tile-1) - (y-yorg) 
			 retval = 1;
		 }
		 else if (select_flag && (surface_select_flag == 1)) {
		    if (select_state == 0) {
				select_state = 5;
				compute_select_points(SP1, SP2, x-xorg, (hgt_rnd_tile-1) - (y-yorg));
				var  tz, t, zscale;
				zscale = (filesdv[FPP[0]].getInt32(file.z_up)) ? UP.getFloat32(zscale) : 1.0;
				tz = (num_media > 1) ? 0.0 : (filesdv[FPP[0]].getFloat32(file.half_zdim));
				t = (tz - SP1[2]) / (SP2[2] - SP1[2]);
				SP[select_target][0] = SP1[0] + t * (SP2[0] - SP1[0]);
				SP[select_target][1] = SP1[1] + t * (SP2[1] - SP1[1]);
				SP[select_target][2] = SP1[2] + t * (SP2[2] - SP1[2]); // should be 0
				SP_valid[select_target] = 1;
		 }
		 select_x = x - xorg;
		 select_y = (hgt_rnd_tile-1) - (y-yorg);
		 retval = 1;
		 }
		return retval;
	}


    function handleMouseDown(event) {
		trace("handleMouseDown");
		mouseDown = true;
        lastMouseX = event.clientX;
        lastMouseY = event.clientY;
		clientstate.select_flag = (event.button == RIGHT_BUTTON);
		select_point(0, clientstate.select_flag, lastMouseX, lastMouseY);
    }


    function handleMouseUp(event) {
		trace("handleMouseUp");
        mouseDown = false;
    }


	var movex = 0, movey = 0;
    function handleMouseMove(event) {
		trace("handleMouseMove");
        if (!mouseDown)  return;
		

      	var newX = event.clientX;
     	var newY = event.clientY;
		if (!event.ctrlKey && !event.shiftKey) {
			if (lastMouseX != newX || lastMouseY != newY) {
				deltaX = (newX-lastMouseX) * 1.2;
				deltaY = (lastMouseY - newY) * 1.2;
			}
		}
		else if (event.ctrlKey) {
			movex += ((newX - lastMouseX)*2)/width;
			movey += ((lastMouseY - newY)*2)/height;
		}
		else if (event.shiftKey) {
			scale += (lastMouseY - newY)/height;
			scale = (scale > 2.0) ? 2.0 : scale;
			scale = (scale < 0.1) ? 0.1 : scale;
		//	var invscale = 1.0/scale;
//			UP.setFloat32(state.fovy, fovy * invscale);
		}

        lastMouseX = newX;
        lastMouseY = newY;
		// moved to drawScene so eye is only updated right before we send packet to server so image generated will be 
		// in sync with bounding box
		//computelookAt();
	   	globalcnt-- ;
		console.log("recv-globalcnt=%d\n", globalcnt);
		if (clientstate.animate) requestid = requestAnimationFrame(animateScene);
		else requestid = requestAnimationFrame(drawScene);
    }

	function imax(x,  y) { return ((x > y) ? x : y);}
	function imax3(w, h, d)
	{
    	var mmax = -1;
    	mmax = imax(w,h);
    	mmax = imax(mmax,d);
    	return mmax;
	}

    var VertexPositionBuffer;
    var VertexIndexBuffer;
    var VertexColorBuffer;
	var VertexTexCoordBuffer;
	var VertexTileCoordBuffer;
    var vertexPositionData;

    function initBuffers() {

		var width = filesdv[clientstate.fileidx].getUint32(file.xdim);
	    var height = filesdv[clientstate.fileidx].getUint32(file.ydim);
	    var depth = filesdv[clientstate.fileidx].getUint32(file.zdim);
		for (i=1; i<num_media; ++i) 
      		depth += filesdv[FPP[i]].getUint32(file.zdim) 

    	// compute scale factor for global bounding box. Will use to draw a global bounding box
    	var scalefactorx =  width * 0.5; // centered at -1...0...1
    	var scalefactory = height  * 0.5;
    	var scalefactorz = depth  * 0.5 * UP.getFloat32(state.zscale);;


	    VertexPositionBuffer = gl.createBuffer();
        gl.bindBuffer(gl.ARRAY_BUFFER, VertexPositionBuffer);
     	vertexPositionData = [
      		// Front face
      		-1.0, -1.0,  1.0,
       		1.0, -1.0,  1.0,
       		1.0,  1.0,  1.0,
      		-1.0,  1.0,  1.0,

      		// Back face
      		-1.0, -1.0, -1.0,
      		-1.0,  1.0, -1.0,
       		1.0,  1.0, -1.0,
       		1.0, -1.0, -1.0,

      		// Top face
      		-1.0,  1.0, -1.0,
      		-1.0,  1.0,  1.0,
       		1.0,  1.0,  1.0,
       		1.0,  1.0, -1.0,

      		// Bottom face
      		-1.0, -1.0, -1.0,
       		1.0, -1.0, -1.0,
       		1.0, -1.0,  1.0,
      		-1.0, -1.0,  1.0,

      		// Right face
       		1.0, -1.0, -1.0,
       		1.0,  1.0, -1.0,
       		1.0,  1.0,  1.0,
       		1.0, -1.0,  1.0,

      		// Left face
      		-1.0, -1.0, -1.0,
      		-1.0, -1.0,  1.0,
      		-1.0,  1.0,  1.0,
      		-1.0,  1.0, -1.0,
   		 ];
    	// initialize vertices for bounding volume box
    	for (var i=0; i<72; i += 3) {
        	vertexPositionData[i] *= scalefactorx;
        	vertexPositionData[i+1] *= scalefactory;
        	vertexPositionData[i+2] *= scalefactorz;
    	}

        gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(vertexPositionData), gl.STATIC_DRAW);
        VertexPositionBuffer.itemSize = 3;
        VertexPositionBuffer.numItems = 24;

		FRONT = 0;
		BACK = 10;
		TOP = 20;
		BOTTOM = 30;
		RIGHT = 40;
		LEFT = 50;
    	VertexIndexBuffer = gl.createBuffer();
    	gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, VertexIndexBuffer);
		var indexData = [
		 	0, 1, 2, 3, 0,     // Front face
      		4, 5, 6, 7, 4,     // Back face
      		8, 9, 10, 11, 8,    // Top face
      		12, 13, 14, 15, 12,  // Bottom face
      		16, 17, 18,  19, 16,// Right face
      		20, 21, 22,  23, 20  // Left face
		];
    	gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, new Uint16Array(indexData), gl.STATIC_DRAW);
    	VertexIndexBuffer.itemSize = 1;

    	VertexIndexBuffer.numItems = 30;

		// tile texture coord buffer
		VertexTexCoordBuffer = gl.createBuffer();
		gl.bindBuffer(gl.ARRAY_BUFFER, VertexTexCoordBuffer);
		var textureCoordinates = [
    	1.0,  0.0,
    	0.0,  0.0,
    	1.0,  1.0,
		0.0,  1.0
		];

  		gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(textureCoordinates), gl.STATIC_DRAW);
		VertexTexCoordBuffer.itemSize = 2;
		VertexTexCoordBuffer.numItems = 4;
		gl.enableVertexAttribArray(tileshaderProgram.vertexTextureAttribute);
		gl.vertexAttribPointer(tileshaderProgram.vertexTextureAttribute, 2, gl.FLOAT, false, 0, 0);

		// tile vertex polygon buffer
		VertexTileCoordBuffer  = gl.createBuffer();
        gl.bindBuffer(gl.ARRAY_BUFFER, VertexTileCoordBuffer );
		gl.enableVertexAttribArray(0);
		gl.vertexAttribPointer(0, 1, gl.FLOAT, false, 0, 0);
        var verts = [
             TILE_X,       0,     -0.5,
				  0,       0,     -0.5,
             TILE_X,  TILE_Y,     -0.5,
				  0,  TILE_Y,     -0.5
        ];
        gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(verts), gl.STATIC_DRAW);
        VertexTileCoordBuffer.itemSize = 3;
        VertexTileCoordBuffer.numItems = 4;
        VertexTileCoordBuffer.primtype = gl.TRIANGLE_STRIP;
		
  }

	function updateServerMatrix(offset, matrix) {

		for (var i=0; i<16; i++) {
			UP.setFloat32(offset, matrix[i]);
			offset += 4;
		}
	}



    function drawTiles() {
		trace("drawTiles", ntiles);
		var i=0;

		gl.enable(gl.BLEND);
		gl.blendFunc(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA);
        gl.useProgram(tileshaderProgram);
		gl.uniform1i(tileshaderProgram.samplerUniform, 0);

		// save current matrices for updatepacket on the stack
		pPushMatrix();
		mvPushMatrix();

		// set up projection matrix once for all the tiles
		mat4.identity(pMatrix);
		mat4.ortho(0, vwid, 0, vhgt, -1, 1, pMatrix);

		gl.activeTexture(gl.TEXTURE0);

		for (i=0; i<ntiles; i++) {
			if (nulltiles[i] != -1) {
				images[i] = new Image();
				(function(index, tex, img) {
					images[i].onload = function() {loadTexture(index, tex, img);};
				})(i, textures[i], images[i]);
				images[i].src = "data:image/png;base64," + encode(tiles[i]);
// new experiment
				nulltiles[i] = -1;
			 	gl.bindTexture(gl.TEXTURE_2D,textures[i]);
				drawTile(i);
// new experiment
			}
		}
// old way
/*
		for (i=0; i < ntiles; i++) {
			if (nulltiles[i] != -1) {
				nulltiles[i] = -1;
			 	gl.bindTexture(gl.TEXTURE_2D,textures[i]);
				drawTile(i);
			}
		}
*/
// old way
		pPopMatrix();
		mvPopMatrix();
	}

    function drawTile(index) {

		trace("drawTile","index=", index);

		// compute the tile move position
		tileidx = index;
		var x = tileidx%ntiles_x;
		var y = (ntiles_y-1) - ((tileidx-x)/ntiles_x);
        x = (x << LOG2_TILE_X);
        y = (y << LOG2_TILE_Y);
			
		// modelview
		mat4.identity(mvMatrix);
		mat4.translate(mvMatrix, [x, y, 0]);

		gl.bindBuffer(gl.ARRAY_BUFFER, VertexTileCoordBuffer);
		gl.vertexAttribPointer(tileshaderProgram.vertexPositionAttribute, VertexTileCoordBuffer.itemSize, gl.FLOAT, false, 0, 0);
		gl.bindBuffer(gl.ARRAY_BUFFER, VertexTexCoordBuffer);
		gl.vertexAttribPointer(tileshaderProgram.vertexTextureAttribute, VertexTexCoordBuffer.itemSize, gl.FLOAT, false, 0, 0);
		setMatrixUniforms(tileshaderProgram);
		gl.drawArrays(VertexTileCoordBuffer.primtype, 0, VertexTileCoordBuffer.numItems);
   }
	function dot3(a, b)
	{
		var dp = (a[0] * b[0]) + (a[1] * b[1]) + (a[2] * b[2]);
		return dp;
	}

	var faces = [
		[0, 0,  1],    	// front
		[0, 0, -1],		// back
		[0, 1,  0], 	// top
		[0, -1, 0],		// bottom
		[1, 0, 0], 		// right
		[-1, 0, 0], 	// left
	];
	var offsets = [0, 10, 20, 30, 40, 50];
	var xface = [];
	var dp = 0;
		
   	function drawBbox(drawTiles) {
		var i=0;


		if (!clientstate.bbox) {
			drawTiles();
			return;
		}
		
		// now draw bounding box - we'll have to draw this so it doesn't overlay the images, but for now...
		gl.useProgram(shaderProgram);
		gl.enable(gl.BLEND);
		gl.blendFunc(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA);

		// draw bbox
		gl.bindBuffer(gl.ARRAY_BUFFER, VertexPositionBuffer);
		gl.vertexAttribPointer(shaderProgram.vertexPositionAttribute, VertexPositionBuffer.itemSize, gl.FLOAT, false, 0, 0);
		gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, VertexIndexBuffer);
		setMatrixUniforms(shaderProgram);
		gl.drawElements(gl.LINE_LOOP, VertexIndexBuffer.numItems, gl.UNSIGNED_SHORT, 0);

		// draw the volume 
		drawTiles();

		// now find face closest to eye and draw again
		gl.useProgram(shaderProgram);
		gl.enable(gl.BLEND);
		gl.blendFunc(gl.DST_ALPHA, gl.ONE_MINUS_DST_ALPHA);

		gl.bindBuffer(gl.ARRAY_BUFFER, VertexPositionBuffer);
		gl.vertexAttribPointer(shaderProgram.vertexPositionAttribute, VertexPositionBuffer.itemSize, gl.FLOAT, false, 0, 0);
		gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, VertexIndexBuffer);
		setMatrixUniforms(shaderProgram);

		// figure our front facing polygons in bbox and draw again
		for (i=0; i<6; i++) {
			var eyevec = [];
		 	eyevec[0] = eye[0] - vertexPositionData[i*12]; 
			eyevec[1] = eye[1] - vertexPositionData[(i*12)+1]; 
		    eyevec[2] =	eye[2] - vertexPositionData[(i*12)+2];

			dp = dot3(faces[i], eyevec);
		    if (dp > 0) gl.drawElements(gl.LINE_LOOP, 5 , gl.UNSIGNED_SHORT, offsets[i]);
		}
    }

	function printout() {
		console.log("just waiting for 50 ticks");
	}

    function animateScene() {

//		trace("animateScene", "serverneedsupdate=",serverneedsupdate, "websocket.ready=", websocket.readyState);
   		requestid = requestAnimationFrame(animateScene);
		if ((serverneedsupdate) && (websocket.readyState)) {
			gl.useProgram(shaderProgram);
			// update the serverstate projection matrix
			var invscale = 1/scale;
			mat4.identity(pMatrix);
			mat4.perspective(fovy*invscale, wid_rnd_tile/hgt_rnd_tile, nearclip, farclip, pMatrix);
			updateProjection(pMatrix);


			// update the timestep counter
			var ts = UP.getInt32(state.timestep) + timestep;
			ts = (ts < 0) ? 0 : ts;
			ts = (ts > n_timesteps_read-1) ? n_timesteps_read-1 : ts;
			UP.setUint32(state.timestep, ts);
       		timesteps.update({
				from: ts,
        	});


			// update the serverstate modelview  matrix
			mat4.identity(mvMatrix);
			mat4.lookAt(eye, center, up, mvMatrix);
			updateModelView(mvMatrix);

			doSend(UP);
			serverneedsupdate = false;
			clientrecvdtiles = 0;
		}

		if (clientrecvdtiles >= ROOTRANKS) {
			gl.clear(gl.COLOR_BUFFER_BIT | gl.ALPHA_BUFFER_BIT);
			drawBbox(drawTiles);
			trace("drawTiles", clientrecvdtiles);
			serverneedsupdate = true;
			clientrecvdtiles = 0;
			UP.setUint32(state.vpchange, 0);
		}
	 }

    function drawScene() {

		trace("drawScene", "serverneedsupdate=",serverneedsupdate, "websocket.ready=", websocket.readyState);
 //  	    requestid = requestAnimationFrame(drawScene);
			
		if ((serverneedsupdate) && (websocket.readyState)) {
			// update the serverstate projection matrix
			var invscale = 1.0/scale;
			UP.setFloat32(state.fovy, fovy * invscale);
			mat4.identity(pMatrix);
			mat4.perspective(fovy*invscale, wid_rnd_tile/hgt_rnd_tile, nearclip, farclip, pMatrix);
			updateProjection(pMatrix);
			pMat = mat4.create(pMatrix);

			// update the serverstate modelview  matrix
			// originally done in mouseMove, but mouseMove called more often than drawScene so better to put it here 
			computelookAt();
			mat4.identity(mvMatrix);
			mat4.lookAt(eye, center, up, mvMatrix);
			updateModelView(mvMatrix);
			mvMat = mat4.create(mvMatrix);

			UP.setUint32(state.select_state, select_state);
			UP.setUint32(state.select_x, select_x);
			UP.setUint32(state.select_y, select_y);
			doSend(UP);
			if (select_state == 1) select_state = 2;
			if (select_state >= 3) select_state = 0;

			clientrecvdtiles = 0;
			serverneedsupdate = false;
			console.log("send-globalcnt=%d\n", globalcnt);
			globalcnt++;
 	  	    requestid = requestAnimationFrame(drawScene);
		}
		if (clientrecvdtiles >= ROOTRANKS) {
			gl.colorMask(true, true, true, true);
			gl.clear(gl.COLOR_BUFFER_BIT | gl.ALPHA_BUFFER_BIT);

			drawBbox(drawTiles);

			serverneedsupdate = true;
			clientrecvdtiles = 0;

//			gl.clearColor(0, 0, 0, 1);
			gl.colorMask(false, false, false, true);
			gl.clear(gl.COLOR_BUFFER_BIT | gl.ALPHA_BUFFER_BIT);
		}

		var xx = [0, vwid];
		var yy = [0, vhgt];
		for (var x=0; x<2; x++) {
			for (var y=0; y<2; y++) {
				drawCoords(xorg+xx[x], yorg+yy[y], 50, 10, "X");
			}
		}
	}

	function drawCoords(w, h, d, delta, mytext) 
	{

//		text.clearRect(0, 0, text.canvas.width, text.canvas.height);
		text.font = '12pt Calibri';
		text.fillStyle = 'white';
		text.fillText(mytext, w, h);
/* this is for paining all the coords along axis
		for (i=0; i<w; i+=dx)
			text.fillText("hello world", 50, 50);
		for (i=0; i<h; i+=dy)
			text.fillText("hello world", 50, 50);
		for (i=0; i<z; i+=dz)
			text.fillText("hello world", 50, 50);
*/
	}


	function resize() {

		var canvas = document.getElementById('dciv-canvas');
		var textcanvas = document.getElementById('text-canvas');

        gl = canvas.getContext("webgl");
 
  		// Lookup the size the browser is displaying the canvas.
		width  = gl.canvas.clientWidth;
        height = gl.canvas.clientHeight;

 
  		// Check if the canvas is not the same size.
  		if (gl.canvas.width  != width ||
      		gl.canvas.height != height) {
 
    		// Make the canvas the same size
        	canvas.width  = width;
        	canvas.height = height;
        	textcanvas.width  = width;
        	textcanvas.height = height;
  		}

		// updates for bbox and serverstate  projections
		wid_rnd_tile = ((width >> LOG2_TILE_X) << LOG2_TILE_X);
		hgt_rnd_tile = ((height >> LOG2_TILE_Y) << LOG2_TILE_Y);
   		if (UP.getUint32(state.wid_rounded_to_tile) != wid_rnd_tile) {
			UP.setUint32(state.vpchange, 1);
			UP.setUint32(state.wid_rounded_to_tile, wid_rnd_tile);
		}
   		if (UP.getUint32(state.hgt_rounded_to_tile) != hgt_rnd_tile) {
			UP.setUint32(state.vpchange, 1);
        	UP.setUint32(state.hgt_rounded_to_tile, hgt_rnd_tile);
		}
		
		if (UP.getUint32(state.vpchange) == 1) {

			ntiles_x = wid_rnd_tile >> LOG2_TILE_Y;
			ntiles_y = hgt_rnd_tile >> LOG2_TILE_Y;
			ntiles = ntiles_x * ntiles_y;
			var aspect = hgt_rnd_tile/wid_rnd_tile;
			vwid = wid_rnd_tile;
			vhgt = vwid*aspect;
			xorg = (width - vwid)/2;	
			yorg = (height - vhgt)/2;	
			gl.viewport(xorg, yorg, vwid-1, vhgt-1);
		}
/*
	    // all the tile images coming from isoparm_Server will be stored in this array	
		nulltiles = new Array(ntiles);
		tiles = new Array(ntiles);
		textures = new Array(ntiles);
        images = new Array(ntiles);
			
		for (var i=0; i<ntiles; i++) {
			nulltiles[i] = -1;
		}
*/

		// udpates for tile projection
// temp debug
/*
    console.log("start\n");
    console.log("width=%d, vwid=%d, height=%d, vhgt=%d\n", width, vwid, height, vhgt)
    console.log("window.innerWidth=%d, window.innerHeight=%d\n", window.innerWidth, window.innerHeight);
    console.log("end\n");
        gl.enable(gl.SCISSOR_TEST);
        gl.scissor(0,0, width-1, height-1);
        gl.clearColor(0.0, 1.0, 1.0, 1.0);
        gl.clear(gl.COLOR_BUFFER_BIT);

        gl.scissor(xorg, yorg, vwid-1, vhgt-1);
        gl.clearColor(1.0, 0.0, 0.0, 1.0);
        gl.clear(gl.COLOR_BUFFER_BIT);
        gl.disable(gl.SCISSOR_TEST);
*/
// end temp debug


		// Camera for bounding box and updatepacket for server
        //gl.useProgram(shaderProgram);
        //mat4.perspective(fovy, wid_rnd_tile/hgt_rnd_tile, nearclip, farclip, pMatrix);
        //updateProjection(pMatrix);

		//serverneedsupdate = true;
		if (clientstate.animate) requestid = requestAnimationFrame(animateScene);
		else requestid = requestAnimationFrame(drawScene);

	}

	function init2D(canvas)
	{
		try {
            // Lookup the size the browser is displaying the canvas.
            textwidth  = canvas.clientWidth;
            textheight = canvas.clientHeight;


            // Check if the canvas is not the same size.
            if (canvas.width  != textwidth ||
                canvas.height != textheight) {

                // Make the canvas the same size
                canvas.width  = textwidth;
                canvas.height = textheight;
            }
            text = canvas.getContext("2d");
        } catch (e) {
			console.log("Error in init 2D context");
        }
        if (!text) {
            alert("Could not initialise 2D, sorry :-(");
            console.log("Could not initialise 2D context, sorry :-(");
        }
	}

    var mouseDown = false;
    var lastMouseX = null;
    var lastMouseY = null;

    function webGLStart() {
		initStatePacket();
		initWidgets();
		var textcanvas = document.getElementById("text-canvas");
		init2D(textcanvas);
        var glcanvas = document.getElementById("dciv-canvas");
        initGL(glcanvas);
		initTextures();
        initShaders();
        initBuffers();
		initCamera();

        gl.clearColor(0.0, 0.0, 0.0, 1.0);
		gl.enable(gl.BLEND);
		gl.blendFunc(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA);

        //window.onmousedown = handleMouseDown;
        //window.onmouseup = handleMouseUp;
        //window.onmousemove = handleMouseMove;
		window.addEventListener('resize', resize, false);
		textcanvas.addEventListener('mousedown', handleMouseDown, false);
		textcanvas.addEventListener('mouseup', handleMouseUp, false);
		textcanvas.addEventListener('mousemove', handleMouseMove, false);

        if (!clientstate.animate) 
			requestid = requestAnimationFrame(drawScene);
		else
			requestid = requestAnimationFrame(animateScene);
    }


// Example of 2D text rendering
//var underCanvas = document.getElementById("under");
//var overCanvas = document.getElementById("over");

// get a webgl context for the under canvas.
//var gl = underCanvas.getContext("webgl");

// get a webgl context for the over canvas.
//var ctx = overCanvas.getContext("2d");

//var radius = 70;
//var clock;
//var x;
//var y;

//function render() {
  
//  clock = Date.now() * 0.001;
 
  
//  x = Math.floor(Math.cos(clock) * radius + gl.canvas.width  * 0.5);
//  y = Math.floor(Math.sin(clock) * radius + gl.canvas.height * 0.5);
  
  
//  drawWebGLStuff(gl);
//  drawCanvas2DStuff(ctx);
  
//  requestAnimationFrame(render);
//}
//render();


//function drawWebGLStuff(gl) {
  // I'm using the SCISSOR because it's the simplest thing
//  gl.disable(gl.SCISSOR_TEST);
//  gl.clearColor(0, 0, 0, 0);
//  gl.clear(gl.COLOR_BUFFER_BIT);
  
//  gl.scissor(
//     Math.max(0, x - 10),
//     Math.max(0, y - 10),
//     20,
//     20);
//  gl.enable(gl.SCISSOR_TEST);
//  gl.clearColor(0, 1, 0, 1);
//  gl.clear(gl.COLOR_BUFFER_BIT);
//}

//function drawCanvas2DStuff() {
//  ctx.clearRect(0, 0, ctx.canvas.width, ctx.canvas.height);
//  ctx.textAlign = "center";
//  ctx.fillText("Hello World", x, ctx.canvas.height - y);
//}
//canvas {
//  border: 1px solid black;
//}
//#under {
//  position: absolute;
//  left: 0px;
//  top: 0px;
//}
/* put "over" on top of "under" */
//#over {
//  position: absolute;
//  left: 0px;
//  top: 0px;
//  z-index: 2;
//}
//<canvas id="under"></canvas>
//<canvas id="over"></canvas>
