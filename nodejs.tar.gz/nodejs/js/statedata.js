/*global $, jQuery, console */
var VPWIDTH = 1536;
var VPHEIGHT = 768;
//var VPWIDTH = 768;
//var VPHEIGHT = 512;
var DEFAULTIDX = 18; //H25
//var DEFAULTIDX = 8; //V1
//var DEFAULTIDX = 9; //V8
//var DEFAULTIDX = 16; //GRF
//var DEFAULTIDX = 2; //B2
//var DEFAULTIDX = 14; //WM8
//var DEFAULTIDX = 3; //S1
var FLIPZ = 1;
var LEVEL = 10;
var SMOOTHING_FACTOR = 3000;
var INITIAL_ALPHA_MULT = 0.5;
var INITIAL_ALPHA_EXP = 1.6;
var DELTASAMPLE = 1.0/1600.0;
var UPDATEPACKETSIZE = 312;
var NUM_FILEPACKETS = 29;
var NUM_DYES = 3;
var NUM_TYPES = 2;
var FILEPACKETSIZE = 160;
var ROOTRANKS = 1;
var LOG2_TILE_X =  8;
var LOG2_TILE_Y =  8;
var TILE_X = (1<<LOG2_TILE_X);
var TILE_Y = (1<<LOG2_TILE_Y);
var TILE_N_ELEMENTS = (TILE_X * TILE_Y);
var MAX_MEDIA = 2;
var num_media = 2; // we'll just hardcode this for now...could pass it to url, but....seems awkward. Probably best idea is to not send the first update packet from webclient until the user sets some key parameters like num_media, filecodes, etc.
var filecodes = ["HAR", "H25"];
var surface_select_flag;
var select_flag;


var trace;
if (0) {
	trace = function trace() {
		if (arguments.length > 0) {
			var output = "";
			for (var i=0; i<arguments.length; i++) {
				output += arguments[i];
				output += " ";
			}
			console.log(output);
		}
	};
} else {
	trace = function trace() {};
}


    var state =  {};
	state.levelval = 0;
    state.modelview_matrix = state.levelval + (MAX_MEDIA * 8);; 
    state.projection_matrix =  state.modelview_matrix + (16 * 4);
	state.data_fileindex  =  state.projection_matrix  + (16 * 4);
    state.media_offset = state.data_fileindex + (MAX_MEDIA * 4);
    state.alpha_m =  state.media_offset + (MAX_MEDIA * 4);
    state.alpha_e =  state.alpha_m +  (MAX_MEDIA * 4);
    state.deltasample =  state.alpha_e + (MAX_MEDIA  * 4);
    state.cutplane =  state.deltasample + (MAX_MEDIA * 4);
    state.view_clipplane =  state.cutplane + (6 * 4);
    state.center =  state.view_clipplane + (2 * 4);
    state.fovy =  state.center  + (3  * 4);
	state.zscale = 	state.fovy + 4;
    state.vpchange =  state.zscale + 4;
	state.num_media =  state.vpchange + 4;
    state.display =  state.num_media +  4;    
    state.wid_rounded_to_tile =  state.display  + 3 * 4;
    state.hgt_rounded_to_tile =  state.wid_rounded_to_tile+4;
    state.killswitch =  state.hgt_rounded_to_tile+4;
	state.pointsize =  state.killswitch +  4;
    state.lighting_enabled =  state.pointsize + 4;
    state.auto_surface =  state.lighting_enabled + 4;
	state.timestep = 	state.auto_surface + 4;
	state.cellsize =  state.timestep +  4;
	state.n_timesteps_available =  state.cellsize + 4;
    state.select_state =  state.n_timesteps_available + 4;
    state.select_x =  state.select_state + 4;
    state.select_y =  state.select_x + 4;
    state.select_target =  state.select_y + 4;
	state.pad = state.select_target + 4;

var file =  {
      code:		0,
      xdim:		4,
      ydim:		8,
      zdim:		12,
      half_xdim:16,
      half_ydim:20,
      half_zdim:24,
      minval:	28,
      maxval:	32,
      z_up:		36,
      near_clip_plane:	40,         // xdim
      far_clip_plane:	44,   // xdim
      distance_to_eye:	48,  // xdim
      vizwoman_file:	52,
      packed_bytes:		56,
	  n_timesteps:		60,
      processed_minval: 64,
      processed_maxval:	72,
      logarithmic_colormap:	80,
      colormap:				84,
      transferfunc:			88,
      filesize:			    92,	
	  init_alpha_m:			96,
	  init_alpha_e:			100,
	  init_level:			104,
	  zscale:				108,
      baked_alpha:			112,
      secondary_filesize:	116,
      file_offset:			120,
      file_stride:			124,
      minlat:				128,
      maxlat:				132,
      minlon:				136,
      maxlon:				140,
      minz:					144,
      maxz:					148,
      delz:					152,
      dell:					156

};

var types = [
		"SURFACE",
		"DEPTH"
]
var dyes = [
		"DRIFTERS",
		"DYE1",
		"DYE2"
]
var models = [
		"K",
		"B",
		"B2",
		"S1",
		"S8",
		"S64",
		"S512",
		"S4096",
		"V1",
		"V8",
		"V64",
		"V512",
		"V4096",
		"WM",
		"WM8",
		"MRI",
		"GDR",
		"H14",
		"H25",
		"H36",
		"HAR",
		"HAS",
		"HAM",
		"H14_R",
		"H25_R",
		"H36_R",
		"HAR_R",
		"HAS_R",
		"HAM_R"
	];

		
		
var FPP = new Uint32Array(MAX_MEDIA);
FPP[0] = 20; FPP[1] = 18;
var files = new Array(NUM_FILEPACKETS);
var filesdv = new Array(NUM_FILEPACKETS);
for (var i=0; i<NUM_FILEPACKETS; i++) {
	files[i] = new ArrayBuffer(FILEPACKETSIZE);
	filesdv[i] = new DataView(files[i]);
}

filesdv[0].setUint32(file.code, "K");
filesdv[0].setUint32(file.xdim, 1001);
filesdv[0].setUint32(file.ydim,  401);
filesdv[0].setUint32(file.zdim,  551);
filesdv[0].setFloat32(file.half_xdim,500.0);
filesdv[0].setFloat32(file.half_ydim,200.0);
filesdv[0].setFloat32(file.half_zdim,275.0);
filesdv[0].setFloat32(file.minval,-1.349812);
filesdv[0].setFloat32(file.maxval,2.130263);
filesdv[0].setInt32(file.z_up,1);
filesdv[0].setFloat32(file.near_clip_plane,1001.0);         // xdim
filesdv[0].setFloat32(file.far_clip_plane,(3.0 * 1001.0));   // xdim
filesdv[0].setFloat32(file.distance_to_eye,(2.0 * 1001.0));  // xdim
filesdv[0].setUint32(file.vizwoman_file,0);
filesdv[0].setUint32(file.packed_bytes,0);
filesdv[0].setUint32(file.n_timesteps, 1);
filesdv[0].setFloat64(file.processed_minval,1000.0);
filesdv[0].setFloat64(file.processed_maxval,5000.0);
filesdv[0].setUint32(file.logarithmic_colormap,1);
filesdv[0].setUint32(file.colormap,0);
filesdv[0].setUint32(file.transferfunc,0);
filesdv[0].setUint32(file.filesize, 0);
filesdv[0].setFloat32(file.init_alpha_m,INITIAL_ALPHA_MULT);
filesdv[0].setFloat32(file.init_alpha_e,INITIAL_ALPHA_EXP);
filesdv[0].setFloat32(file.init_level,4999.0);
filesdv[0].setFloat32(file.zscale,1.0);
filesdv[0].setInt32(file.baked_alpha,0);
filesdv[0].setInt32(file.secondary_filesize, 0);
filesdv[0].setInt32(file.offset, 0);
filesdv[0].setInt32(file.stride, 1);
filesdv[0].setFloat32(file.minlat,0.0);
filesdv[0].setFloat32(file.maxlot,1.0);
filesdv[0].setFloat32(file.minlon,0.0);
filesdv[0].setFloat32(file.maxlon,1.0);
filesdv[0].setFloat32(file.minz,0.0);
filesdv[0].setFloat32(file.maxz,1.0);
filesdv[0].setFloat32(file.delz,1.0);
filesdv[0].setFloat32(file.dell,1.0);


filesdv[1].setUint32(file.code, "B");
filesdv[1].setUint32(file.xdim, 256);
filesdv[1].setUint32(file.ydim,  256);
filesdv[1].setUint32(file.zdim,  256);
filesdv[1].setFloat32(file.half_xdim,128.0);
filesdv[1].setFloat32(file.half_ydim,128.0);
filesdv[1].setFloat32(file.half_zdim,112.0);
filesdv[1].setFloat32(file.minval,0.0);
filesdv[1].setFloat32(file.maxval,4080.75);
filesdv[1].setInt32(file.z_up,1);
filesdv[1].setFloat32(file.near_clip_plane,256.0);         // xdim
filesdv[1].setFloat32(file.far_clip_plane,(3.0 * 256.0));   // xdim
filesdv[1].setFloat32(file.distance_to_eye,(2.0 * 256.0));  // xdim
filesdv[1].setUint32(file.vizwoman_file,0);
filesdv[1].setUint32(file.packed_bytes,0);
filesdv[1].setUint32(file.n_timesteps, 1);
filesdv[1].setFloat64(file.processed_minval,1000.0);
filesdv[1].setFloat64(file.processed_maxval,5000.0);
filesdv[1].setUint32(file.logarithmic_colormap,0);
filesdv[1].setUint32(file.colormap,2);
filesdv[1].setUint32(file.transferfunc,0);
filesdv[1].setUint32(file.filesize, 0);
filesdv[1].setFloat32(file.init_alpha_m,INITIAL_ALPHA_MULT);
filesdv[1].setFloat32(file.init_alpha_e,INITIAL_ALPHA_EXP);
filesdv[1].setFloat32(file.init_level,4999.0);
filesdv[1].setFloat32(file.zscale,1.0);
filesdv[1].setInt32(file.baked_alpha,0);
filesdv[1].setInt32(file.secondary_filesize, 0);
filesdv[1].setInt32(file.offset, 0);
filesdv[1].setInt32(file.stride, 1);
filesdv[1].setFloat32(file.minlat,0.0);
filesdv[1].setFloat32(file.maxlot,1.0);
filesdv[1].setFloat32(file.minlon,0.0);
filesdv[1].setFloat32(file.maxlon,1.0);
filesdv[1].setFloat32(file.minz,0.0);
filesdv[1].setFloat32(file.maxz,1.0);
filesdv[1].setFloat32(file.delz,1.0);
filesdv[1].setFloat32(file.dell,1.0);


filesdv[2].setUint32(file.code, "B2");
filesdv[2].setUint32(file.xdim, 256);
filesdv[2].setUint32(file.ydim,  256);
filesdv[2].setUint32(file.zdim,  256);
filesdv[2].setFloat32(file.half_xdim,128.0);
filesdv[2].setFloat32(file.half_ydim,128.0);
filesdv[2].setFloat32(file.half_zdim,128.0);
filesdv[2].setFloat32(file.minval,0.0);
filesdv[2].setFloat32(file.maxval,16.0 * 255.0);
filesdv[2].setInt32(file.z_up,1);
filesdv[2].setFloat32(file.near_clip_plane,256.0);         // xdim
filesdv[2].setFloat32(file.far_clip_plane,(3.0 * 256.0));   // xdim
filesdv[2].setFloat32(file.distance_to_eye,(2.0 * 256.0));  // xdim
filesdv[2].setUint32(file.vizwoman_file,0);
filesdv[2].setUint32(file.packed_bytes,0);
filesdv[2].setUint32(file.n_timesteps, 1);
filesdv[2].setFloat64(file.processed_minval,1000.0);
filesdv[2].setFloat64(file.processed_maxval,5000.0);
filesdv[2].setUint32(file.logarithmic_colormap,0);
filesdv[2].setUint32(file.colormap,2);
filesdv[2].setUint32(file.transferfunc,0);
filesdv[2].setUint32(file.filesize, 0);
filesdv[2].setFloat32(file.init_alpha_m,INITIAL_ALPHA_MULT);
filesdv[2].setFloat32(file.init_alpha_e,INITIAL_ALPHA_EXP);
filesdv[2].setFloat32(file.init_level,4999.0);
filesdv[2].setFloat32(file.zscale,1.0);
filesdv[2].setInt32(file.baked_alpha,1);
filesdv[2].setInt32(file.secondary_filesize, 0);
filesdv[2].setInt32(file.offset, 0);
filesdv[2].setInt32(file.stride, 1);
filesdv[2].setFloat32(file.minlat,0.0);
filesdv[2].setFloat32(file.maxlot,1.0);
filesdv[2].setFloat32(file.minlon,0.0);
filesdv[2].setFloat32(file.maxlon,1.0);
filesdv[2].setFloat32(file.minz,0.0);
filesdv[2].setFloat32(file.maxz,1.0);
filesdv[2].setFloat32(file.delz,1.0);
filesdv[2].setFloat32(file.dell,1.0);


filesdv[3].setUint32(file.code, "S1");
filesdv[3].setUint32(file.xdim, 1001);
filesdv[3].setUint32(file.ydim,  401);
filesdv[3].setUint32(file.zdim,  551);
filesdv[3].setFloat32(file.half_xdim,500.0);
filesdv[3].setFloat32(file.half_ydim,200.0);
filesdv[3].setFloat32(file.half_zdim,275.0);
filesdv[3].setFloat32(file.minval,-1.349812);
filesdv[3].setFloat32(file.maxval,2.130263);
filesdv[3].setInt32(file.z_up,1);
filesdv[3].setFloat32(file.near_clip_plane,1001.0);         // xdim
filesdv[3].setFloat32(file.far_clip_plane,(3.0 * 1001.0));   // xdim
filesdv[3].setFloat32(file.distance_to_eye,(2.0 * 1001.0));  // xdim
filesdv[3].setUint32(file.vizwoman_file,0);
filesdv[3].setUint32(file.packed_bytes,0);
filesdv[3].setUint32(file.n_timesteps, 1);
filesdv[3].setFloat64(file.processed_minval,1000.0);
filesdv[3].setFloat64(file.processed_maxval,5000.0);
filesdv[3].setUint32(file.logarithmic_colormap,0);
filesdv[3].setUint32(file.colormap,4);
filesdv[3].setUint32(file.transferfunc,0);
filesdv[3].setUint32(file.filesize, 0);
filesdv[3].setFloat32(file.init_alpha_m,INITIAL_ALPHA_MULT);
filesdv[3].setFloat32(file.init_alpha_e,INITIAL_ALPHA_EXP);
filesdv[3].setFloat32(file.init_level,4999.0);
filesdv[3].setFloat32(file.zscale,1.0);
filesdv[3].setInt32(file.baked_alpha,0);
filesdv[3].setInt32(file.secondary_filesize, 0);
filesdv[3].setInt32(file.offset, 0);
filesdv[3].setInt32(file.stride, 1);
filesdv[3].setFloat32(file.minlat,0.0);
filesdv[3].setFloat32(file.maxlot,1.0);
filesdv[3].setFloat32(file.minlon,0.0);
filesdv[3].setFloat32(file.maxlon,1.0);
filesdv[3].setFloat32(file.minz,0.0);
filesdv[3].setFloat32(file.maxz,1.0);
filesdv[3].setFloat32(file.delz,1.0);
filesdv[3].setFloat32(file.dell,1.0);


filesdv[4].setUint32(file.code, "S8");
filesdv[4].setUint32(file.xdim, 2001);
filesdv[4].setUint32(file.ydim,  801);
filesdv[4].setUint32(file.zdim,  1101);
filesdv[4].setFloat32(file.half_xdim,1000.0);
filesdv[4].setFloat32(file.half_ydim,400.0);
filesdv[4].setFloat32(file.half_zdim,550.0);
filesdv[4].setFloat32(file.minval,1459.327148);
filesdv[4].setFloat32(file.maxval,5101.787109);
filesdv[4].setInt32(file.z_up,1);
filesdv[4].setFloat32(file.near_clip_plane,2001.0);         // xdim
filesdv[4].setFloat32(file.far_clip_plane,(3.0 * 2001.0));   // xdim
filesdv[4].setFloat32(file.distance_to_eye,(2.0 * 2001.0));  // xdim
filesdv[4].setUint32(file.vizwoman_file,0);
filesdv[4].setUint32(file.packed_bytes,0);
filesdv[4].setUint32(file.n_timesteps, 1);
filesdv[4].setFloat64(file.processed_minval,1000.0);
filesdv[4].setFloat64(file.processed_maxval,5000.0);
filesdv[4].setUint32(file.logarithmic_colormap,0);
filesdv[4].setUint32(file.colormap,4);
filesdv[4].setUint32(file.transferfunc,0);
filesdv[4].setUint32(file.filesize, 0);
filesdv[4].setFloat32(file.init_alpha_m,INITIAL_ALPHA_MULT);
filesdv[4].setFloat32(file.init_alpha_e,INITIAL_ALPHA_EXP);
filesdv[4].setFloat32(file.init_level,4999.0);
filesdv[4].setFloat32(file.zscale,1.0);
filesdv[4].setInt32(file.baked_alpha,0);
filesdv[4].setInt32(file.secondary_filesize, 0);
filesdv[4].setInt32(file.offset, 0);
filesdv[4].setInt32(file.stride, 1);
filesdv[4].setFloat32(file.minlat,0.0);
filesdv[4].setFloat32(file.maxlot,1.0);
filesdv[4].setFloat32(file.minlon,0.0);
filesdv[4].setFloat32(file.maxlon,1.0);
filesdv[4].setFloat32(file.minz,0.0);
filesdv[4].setFloat32(file.maxz,1.0);
filesdv[4].setFloat32(file.delz,1.0);
filesdv[4].setFloat32(file.dell,1.0);


filesdv[5].setUint32(file.code, "S64");
filesdv[5].setUint32(file.xdim, 4001);
filesdv[5].setUint32(file.ydim,  1601);
filesdv[5].setUint32(file.zdim,  2201);
filesdv[5].setFloat32(file.half_xdim,2000.0);
filesdv[5].setFloat32(file.half_ydim,800.0);
filesdv[5].setFloat32(file.half_zdim,1100.0);
filesdv[5].setFloat32(file.minval,1459.327148);
filesdv[5].setFloat32(file.maxval,5101.787109);
filesdv[5].setInt32(file.z_up,1);
filesdv[5].setFloat32(file.near_clip_plane,4001.0);         // xdim
filesdv[5].setFloat32(file.far_clip_plane,(3.0 * 4001.0));   // xdim
filesdv[5].setFloat32(file.distance_to_eye,(2.0 * 4001.0));  // xdim
filesdv[5].setUint32(file.vizwoman_file,0);
filesdv[5].setUint32(file.packed_bytes,0);
filesdv[5].setUint32(file.n_timesteps, 1);
filesdv[5].setFloat64(file.processed_minval,1000.0);
filesdv[5].setFloat64(file.processed_maxval,5000.0);
filesdv[5].setUint32(file.logarithmic_colormap,0);
filesdv[5].setUint32(file.colormap,4);
filesdv[5].setUint32(file.transferfunc,0);
filesdv[5].setUint32(file.filesize, 0);
filesdv[5].setFloat32(file.init_alpha_m,INITIAL_ALPHA_MULT);
filesdv[5].setFloat32(file.init_alpha_e,INITIAL_ALPHA_EXP);
filesdv[5].setFloat32(file.init_level, 4999.0);
filesdv[5].setFloat32(file.zscale,1.0);
filesdv[5].setInt32(file.baked_alpha,0);
filesdv[5].setInt32(file.secondary_filesize, 0);
filesdv[5].setInt32(file.offset, 0);
filesdv[5].setInt32(file.stride, 1);
filesdv[5].setFloat32(file.minlat,0.0);
filesdv[5].setFloat32(file.maxlot,1.0);
filesdv[5].setFloat32(file.minlon,0.0);
filesdv[5].setFloat32(file.maxlon,1.0);
filesdv[5].setFloat32(file.minz,0.0);
filesdv[5].setFloat32(file.maxz,1.0);
filesdv[5].setFloat32(file.delz,1.0);
filesdv[5].setFloat32(file.dell,1.0);


filesdv[6].setUint32(file.code, "S512");
filesdv[6].setUint32(file.xdim, 8001);
filesdv[6].setUint32(file.ydim,  3201);
filesdv[6].setUint32(file.zdim,  4401);
filesdv[6].setFloat32(file.half_xdim,4000.0);
filesdv[6].setFloat32(file.half_ydim,1600.0);
filesdv[6].setFloat32(file.half_zdim,2200.0);
filesdv[6].setFloat32(file.minval,1459.327148);
filesdv[6].setFloat32(file.maxval,5101.787109);
filesdv[6].setInt32(file.z_up,1);
filesdv[6].setFloat32(file.near_clip_plane,8001.0);         // xdim
filesdv[6].setFloat32(file.far_clip_plane,(3.0 * 8001.0));   // xdim
filesdv[6].setFloat32(file.distance_to_eye,(2.0 * 8001.0));  // xdim
filesdv[6].setUint32(file.vizwoman_file,0);
filesdv[6].setUint32(file.packed_bytes,0);
filesdv[6].setUint32(file.n_timesteps, 1);
filesdv[6].setFloat64(file.processed_minval,1000.0);
filesdv[6].setFloat64(file.processed_maxval,5000.0);
filesdv[6].setUint32(file.logarithmic_colormap,0);
filesdv[6].setUint32(file.colormap,4);
filesdv[6].setUint32(file.transferfunc,0);
filesdv[6].setUint32(file.filesize, 0);
filesdv[6].setFloat32(file.init_alpha_m,INITIAL_ALPHA_MULT);
filesdv[6].setFloat32(file.init_alpha_e,INITIAL_ALPHA_EXP);
filesdv[6].setFloat32(file.init_level, 4999.0);
filesdv[6].setFloat32(file.zscale,1.0);
filesdv[6].setInt32(file.baked_alpha,0);
filesdv[6].setInt32(file.secondary_filesize, 0);
filesdv[6].setInt32(file.offset, 0);
filesdv[6].setInt32(file.stride, 1);
filesdv[6].setFloat32(file.minlat,0.0);
filesdv[6].setFloat32(file.maxlot,1.0);
filesdv[6].setFloat32(file.minlon,0.0);
filesdv[6].setFloat32(file.maxlon,1.0);
filesdv[6].setFloat32(file.minz,0.0);
filesdv[6].setFloat32(file.maxz,1.0);
filesdv[6].setFloat32(file.delz,1.0);
filesdv[6].setFloat32(file.dell,1.0);


filesdv[7].setUint32(file.code, "S4096");
filesdv[7].setUint32(file.xdim, 16001);
filesdv[7].setUint32(file.ydim,  6401);
filesdv[7].setUint32(file.zdim,  8801);
filesdv[7].setFloat32(file.half_xdim,8000.0);
filesdv[7].setFloat32(file.half_ydim,3200.0);
filesdv[7].setFloat32(file.half_zdim,4400.0);
filesdv[7].setFloat32(file.minval,1459.327148);
filesdv[7].setFloat32(file.maxval,5101.787109);
filesdv[7].setInt32(file.z_up,1);
filesdv[7].setFloat32(file.near_clip_plane,16001.0);         // xdim
filesdv[7].setFloat32(file.far_clip_plane,(3.0 * 16001.0));   // xdim
filesdv[7].setFloat32(file.distance_to_eye,(2.0 * 16001.0));  // xdim
filesdv[7].setUint32(file.vizwoman_file,0);
filesdv[7].setUint32(file.packed_bytes,0);
filesdv[7].setUint32(file.n_timesteps, 1);
filesdv[7].setFloat64(file.processed_minval,1000.0);
filesdv[7].setFloat64(file.processed_maxval,5000.0);
filesdv[7].setUint32(file.logarithmic_colormap,0);
filesdv[7].setUint32(file.colormap,4);
filesdv[7].setUint32(file.transferfunc,0);
filesdv[7].setUint32(file.filesize, 0);
filesdv[7].setFloat32(file.init_alpha_m,INITIAL_ALPHA_MULT);
filesdv[7].setFloat32(file.init_alpha_e,INITIAL_ALPHA_EXP);
filesdv[7].setFloat32(file.init_level, 4999.0);
filesdv[7].setFloat32(file.zscale,1.0);
filesdv[7].setInt32(file.baked_alpha,0);
filesdv[7].setInt32(file.secondary_filesize, 0);
filesdv[7].setInt32(file.offset, 0);
filesdv[7].setInt32(file.stride, 1);
filesdv[7].setFloat32(file.minlat,0.0);
filesdv[7].setFloat32(file.maxlot,1.0);
filesdv[7].setFloat32(file.minlon,0.0);
filesdv[7].setFloat32(file.maxlon,1.0);
filesdv[7].setFloat32(file.minz,0.0);
filesdv[7].setFloat32(file.maxz,1.0);
filesdv[7].setFloat32(file.delz,1.0);
filesdv[7].setFloat32(file.dell,1.0);


filesdv[8].setUint32(file.code, "V1");
filesdv[8].setUint32(file.xdim, 512);
filesdv[8].setUint32(file.ydim,  304);
filesdv[8].setUint32(file.zdim,  1297);
filesdv[8].setFloat32(file.half_xdim,256.0);
filesdv[8].setFloat32(file.half_ydim,152.0);
filesdv[8].setFloat32(file.half_zdim,648.5);
filesdv[8].setFloat32(file.minval,0.0);
filesdv[8].setFloat32(file.maxval,4294967295.0);
filesdv[8].setInt32(file.z_up,0);
filesdv[8].setFloat32(file.near_clip_plane,1297.0);         // xdim
filesdv[8].setFloat32(file.far_clip_plane,(3.0 * 1297.0));   // xdim
filesdv[8].setFloat32(file.distance_to_eye,(2.0 * 1297.0));  // xdim
filesdv[8].setUint32(file.vizwoman_file,1);
filesdv[8].setUint32(file.packed_bytes,1);
filesdv[8].setUint32(file.n_timesteps, 1);
filesdv[8].setFloat64(file.processed_minval,0.0);
filesdv[8].setFloat64(file.processed_maxval, 4294967295.0);
filesdv[8].setUint32(file.logarithmic_colormap,0);
filesdv[8].setUint32(file.colormap,0);
filesdv[8].setUint32(file.transferfunc,0);
filesdv[8].setUint32(file.filesize, 0);
filesdv[8].setFloat32(file.init_alpha_m,INITIAL_ALPHA_MULT);
filesdv[8].setFloat32(file.init_alpha_e,INITIAL_ALPHA_EXP);
filesdv[8].setFloat32(file.init_level, 4999.0);
filesdv[8].setFloat32(file.zscale,1.0);
filesdv[8].setInt32(file.baked_alpha,0);
filesdv[8].setInt32(file.secondary_filesize, 0);
filesdv[8].setInt32(file.offset, 0);
filesdv[8].setInt32(file.stride, 1);
filesdv[8].setFloat32(file.minlat,0.0);
filesdv[8].setFloat32(file.maxlot,1.0);
filesdv[8].setFloat32(file.minlon,0.0);
filesdv[8].setFloat32(file.maxlon,1.0);
filesdv[8].setFloat32(file.minz,0.0);
filesdv[8].setFloat32(file.maxz,1.0);
filesdv[8].setFloat32(file.delz,1.0);
filesdv[8].setFloat32(file.dell,1.0);


filesdv[9].setUint32(file.code, "V8");
filesdv[9].setUint32(file.xdim, 1024);
filesdv[9].setUint32(file.ydim,  608);
filesdv[9].setUint32(file.zdim,  2594);
filesdv[9].setFloat32(file.half_xdim,512.0);
filesdv[9].setFloat32(file.half_ydim,304.0);
filesdv[9].setFloat32(file.half_zdim,1297.0);
filesdv[9].setFloat32(file.minval,0.0);
filesdv[9].setFloat32(file.maxval,4294967295.0);
filesdv[9].setInt32(file.z_up,0);
filesdv[9].setFloat32(file.near_clip_plane,2594.0);         // xdim
filesdv[9].setFloat32(file.far_clip_plane,(3.0 * 2594.0));   // xdim
filesdv[9].setFloat32(file.distance_to_eye,(2.0 * 2594.0));  // xdim
filesdv[9].setUint32(file.vizwoman_file,1);
filesdv[9].setUint32(file.packed_bytes,1);
filesdv[9].setUint32(file.n_timesteps, 1);
filesdv[9].setFloat64(file.processed_minval,0.0);
filesdv[9].setFloat64(file.processed_maxval,4294967295.0);
filesdv[9].setUint32(file.logarithmic_colormap,0);
filesdv[9].setUint32(file.colormap,0);
filesdv[9].setUint32(file.transferfunc,0);
filesdv[9].setUint32(file.filesize, 0);
filesdv[9].setFloat32(file.init_alpha_m,INITIAL_ALPHA_MULT);
filesdv[9].setFloat32(file.init_alpha_e,INITIAL_ALPHA_EXP);
filesdv[9].setFloat32(file.init_level, 4999.0);
filesdv[9].setFloat32(file.zscale,1.0);
filesdv[9].setInt32(file.baked_alpha,0);
filesdv[9].setInt32(file.secondary_filesize, 0);
filesdv[9].setInt32(file.offset, 0);
filesdv[9].setInt32(file.stride, 1);
filesdv[9].setFloat32(file.minlat,0.0);
filesdv[9].setFloat32(file.maxlot,1.0);
filesdv[9].setFloat32(file.minlon,0.0);
filesdv[9].setFloat32(file.maxlon,1.0);
filesdv[9].setFloat32(file.minz,0.0);
filesdv[9].setFloat32(file.maxz,1.0);
filesdv[9].setFloat32(file.delz,1.0);
filesdv[9].setFloat32(file.dell,1.0);


filesdv[10].setUint32(file.code, "V64");
filesdv[10].setUint32(file.xdim, 2048);
filesdv[10].setUint32(file.ydim,  1216);
filesdv[10].setUint32(file.zdim,  5189);
filesdv[10].setFloat32(file.half_xdim,1024.0);
filesdv[10].setFloat32(file.half_ydim,608.0);
filesdv[10].setFloat32(file.half_zdim,2594.0);
filesdv[10].setFloat32(file.minval,0.0);
filesdv[10].setFloat32(file.maxval,4294967295.0);
filesdv[10].setInt32(file.z_up,0);
filesdv[10].setFloat32(file.near_clip_plane,2594.0);         // xdim
filesdv[10].setFloat32(file.far_clip_plane,(3.0 * 2594.0));   // xdim
filesdv[10].setFloat32(file.distance_to_eye,(2.0 * 2594.0));  // xdim
filesdv[10].setUint32(file.vizwoman_file,1);
filesdv[10].setUint32(file.packed_bytes,1);
filesdv[10].setUint32(file.n_timesteps, 1);
filesdv[10].setFloat64(file.processed_minval,0.0);
filesdv[10].setFloat64(file.processed_maxval,4294967295.0);
filesdv[10].setUint32(file.logarithmic_colormap,0);
filesdv[10].setUint32(file.colormap,0);
filesdv[10].setUint32(file.transferfunc,0);
filesdv[10].setUint32(file.filesize, 0);
filesdv[10].setFloat32(file.init_alpha_m,INITIAL_ALPHA_MULT);
filesdv[10].setFloat32(file.init_alpha_e,INITIAL_ALPHA_EXP);
filesdv[10].setFloat32(file.init_level, 4999.0);
filesdv[10].setFloat32(file.zscale,1.0);
filesdv[10].setInt32(file.baked_alpha,0);
filesdv[10].setInt32(file.secondary_filesize, 0);
filesdv[10].setInt32(file.offset, 0);
filesdv[10].setInt32(file.stride, 1);
filesdv[10].setFloat32(file.minlat,0.0);
filesdv[10].setFloat32(file.maxlot,1.0);
filesdv[10].setFloat32(file.minlon,0.0);
filesdv[10].setFloat32(file.maxlon,1.0);
filesdv[10].setFloat32(file.minz,0.0);
filesdv[10].setFloat32(file.maxz,1.0);
filesdv[10].setFloat32(file.delz,1.0);
filesdv[10].setFloat32(file.dell,1.0);


filesdv[11].setUint32(file.code, "V512");
filesdv[11].setUint32(file.xdim, 4095);
filesdv[11].setUint32(file.ydim,  2431);
filesdv[11].setUint32(file.zdim,  10377);
filesdv[11].setFloat32(file.half_xdim,2047.0);
filesdv[11].setFloat32(file.half_ydim,1215.0);
filesdv[11].setFloat32(file.half_zdim,5188.0);
filesdv[11].setFloat32(file.minval,0.0);
filesdv[11].setFloat32(file.maxval,4294967295.0);
filesdv[11].setInt32(file.z_up,0);
filesdv[11].setFloat32(file.near_clip_plane,10377.0);         // xdim
filesdv[11].setFloat32(file.far_clip_plane,(3.0 * 10377.0));   // xdim
filesdv[11].setFloat32(file.distance_to_eye,(2.0 * 10377.0));  // xdim
filesdv[11].setUint32(file.vizwoman_file,1);
filesdv[11].setUint32(file.packed_bytes,1);
filesdv[11].setUint32(file.n_timesteps, 1);
filesdv[11].setFloat64(file.processed_minval,0.0);
filesdv[11].setFloat64(file.processed_maxval,4294967295.0);
filesdv[11].setUint32(file.logarithmic_colormap,0);
filesdv[11].setUint32(file.colormap,0);
filesdv[11].setUint32(file.transferfunc,0);
filesdv[11].setUint32(file.filesize, 0);
filesdv[11].setFloat32(file.init_alpha_m,INITIAL_ALPHA_MULT);
filesdv[11].setFloat32(file.init_alpha_e,INITIAL_ALPHA_EXP);
filesdv[11].setFloat32(file.init_level,4999.0);
filesdv[11].setFloat32(file.zscale,1.0);
filesdv[11].setInt32(file.baked_alpha,0);
filesdv[11].setInt32(file.secondary_filesize, 0);
filesdv[11].setInt32(file.offset, 0);
filesdv[11].setInt32(file.stride, 1);
filesdv[11].setFloat32(file.minlat,0.0);
filesdv[11].setFloat32(file.maxlot,1.0);
filesdv[11].setFloat32(file.minlon,0.0);
filesdv[11].setFloat32(file.maxlon,1.0);
filesdv[11].setFloat32(file.minz,0.0);
filesdv[11].setFloat32(file.maxz,1.0);
filesdv[11].setFloat32(file.delz,1.0);
filesdv[11].setFloat32(file.dell,1.0);



filesdv[12].setUint32(file.code, "V4096");
filesdv[12].setUint32(file.xdim, 8189);
filesdv[12].setUint32(file.ydim,  4861);
filesdv[12].setUint32(file.zdim,  20753);
filesdv[12].setFloat32(file.half_xdim,4094.0);
filesdv[12].setFloat32(file.half_ydim,2430.0);
filesdv[12].setFloat32(file.half_zdim,10376.0);
filesdv[12].setFloat32(file.minval,0.0);
filesdv[12].setFloat32(file.maxval,4294967295.0);
filesdv[12].setInt32(file.z_up,0);
filesdv[12].setFloat32(file.near_clip_plane,20753.0);         // xdim
filesdv[12].setFloat32(file.far_clip_plane,(3.0 * 20753.0));   // xdim
filesdv[12].setFloat32(file.distance_to_eye,(2.0 * 20753.0));  // xdim
filesdv[12].setUint32(file.vizwoman_file,1);
filesdv[12].setUint32(file.packed_bytes,1);
filesdv[12].setUint32(file.n_timesteps, 1);
filesdv[12].setFloat64(file.processed_minval,0.0);
filesdv[12].setFloat64(file.processed_maxval,4294967295.0);
filesdv[12].setUint32(file.logarithmic_colormap,0);
filesdv[12].setUint32(file.colormap,0);
filesdv[12].setUint32(file.transferfunc,0);
filesdv[12].setUint32(file.filesize, 0);
filesdv[12].setFloat32(file.init_alpha_m,INITIAL_ALPHA_MULT);
filesdv[12].setFloat32(file.init_alpha_e,INITIAL_ALPHA_EXP);
filesdv[12].setFloat32(file.init_level,4999.0);
filesdv[12].setFloat32(file.zscale,1.0);
filesdv[12].setInt32(file.baked_alpha,0);
filesdv[12].setInt32(file.secondary_filesize, 0);
filesdv[12].setInt32(file.offset, 0);
filesdv[12].setInt32(file.stride, 1);
filesdv[12].setFloat32(file.minlat,0.0);
filesdv[12].setFloat32(file.maxlot,1.0);
filesdv[12].setFloat32(file.minlon,0.0);
filesdv[12].setFloat32(file.maxlon,1.0);
filesdv[12].setFloat32(file.minz,0.0);
filesdv[12].setFloat32(file.maxz,1.0);
filesdv[12].setFloat32(file.delz,1.0);
filesdv[12].setFloat32(file.dell,1.0);



filesdv[13].setUint32(file.code, "WM");
filesdv[13].setUint32(file.xdim, 177);
filesdv[13].setUint32(file.ydim,  177);
filesdv[13].setUint32(file.zdim,  95);
filesdv[13].setFloat32(file.half_xdim,88.5);
filesdv[13].setFloat32(file.half_ydim,88.50);
filesdv[13].setFloat32(file.half_zdim,47.50);
filesdv[13].setFloat32(file.minval,-30.0);
filesdv[13].setFloat32(file.maxval,72.849);
filesdv[13].setInt32(file.z_up,1);
filesdv[13].setFloat32(file.near_clip_plane,177.0);         // xdim
filesdv[13].setFloat32(file.far_clip_plane,(3.0 * 177.0));   // xdim
filesdv[13].setFloat32(file.distance_to_eye,(2.0 * 177.0));  // xdim
filesdv[13].setUint32(file.vizwoman_file,0);
filesdv[13].setUint32(file.packed_bytes,0);
filesdv[13].setUint32(file.n_timesteps, 217);
filesdv[13].setFloat64(file.processed_minval,1000.0);
filesdv[13].setFloat64(file.processed_maxval,5000.0);
filesdv[13].setUint32(file.logarithmic_colormap,0);
filesdv[13].setUint32(file.colormap,5);
filesdv[13].setUint32(file.transferfunc,0);
filesdv[13].setUint32(file.filesize, 0);
filesdv[13].setFloat32(file.init_alpha_m,INITIAL_ALPHA_MULT);
filesdv[13].setFloat32(file.init_alpha_e,INITIAL_ALPHA_EXP);
filesdv[13].setFloat32(file.init_level,4999.0);
filesdv[13].setFloat32(file.zscale,1.0);
filesdv[13].setInt32(file.baked_alpha,0);
filesdv[13].setInt32(file.secondary_filesize, 0);
filesdv[13].setInt32(file.offset, 0);
filesdv[13].setInt32(file.stride, 1);
filesdv[13].setFloat32(file.minlat,0.0);
filesdv[13].setFloat32(file.maxlot,1.0);
filesdv[13].setFloat32(file.minlon,0.0);
filesdv[13].setFloat32(file.maxlon,1.0);
filesdv[13].setFloat32(file.minz,0.0);
filesdv[13].setFloat32(file.maxz,1.0);
filesdv[13].setFloat32(file.delz,1.0);
filesdv[13].setFloat32(file.dell,1.0);



filesdv[14].setUint32(file.code, "WM8");
filesdv[14].setUint32(file.xdim, 353);
filesdv[14].setUint32(file.ydim,  353);
filesdv[14].setUint32(file.zdim,  189);
filesdv[14].setFloat32(file.half_xdim,176.5);
filesdv[14].setFloat32(file.half_ydim,176.5);
filesdv[14].setFloat32(file.half_zdim,94.5);
filesdv[14].setFloat32(file.minval,-30.0);
filesdv[14].setFloat32(file.maxval,72.849);
filesdv[14].setInt32(file.z_up,1);
filesdv[14].setFloat32(file.near_clip_plane,353.0);         // xdim
filesdv[14].setFloat32(file.far_clip_plane,(3.0 * 353.0));   // xdim
filesdv[14].setFloat32(file.distance_to_eye,(2.0 * 353.0));  // xdim
filesdv[14].setUint32(file.vizwoman_file,0);
filesdv[14].setUint32(file.packed_bytes,0);
filesdv[14].setUint32(file.n_timesteps,75);
filesdv[14].setFloat64(file.processed_minval,1000.0);
filesdv[14].setFloat64(file.processed_maxval,5000.0);
filesdv[14].setUint32(file.logarithmic_colormap,0);
filesdv[14].setUint32(file.colormap,5);
filesdv[14].setUint32(file.transferfunc,0);
filesdv[14].setUint32(file.filesize, 94204404);
filesdv[14].setFloat32(file.init_alpha_m,0.2);
filesdv[14].setFloat32(file.init_alpha_e,INITIAL_ALPHA_EXP);
filesdv[14].setFloat32(file.init_level,4999.0);
filesdv[14].setFloat32(file.zscale,0.4);
filesdv[14].setInt32(file.baked_alpha,0);
filesdv[14].setInt32(file.secondary_filesize, 0);
filesdv[14].setInt32(file.offset, 0);
filesdv[14].setInt32(file.stride, 1);
filesdv[14].setFloat32(file.minlat,0.0);
filesdv[14].setFloat32(file.maxlot,1.0);
filesdv[14].setFloat32(file.minlon,0.0);
filesdv[14].setFloat32(file.maxlon,1.0);
filesdv[14].setFloat32(file.minz,0.0);
filesdv[14].setFloat32(file.maxz,1.0);
filesdv[14].setFloat32(file.delz,1.0);
filesdv[14].setFloat32(file.dell,1.0);



filesdv[15].setUint32(file.code, "MRI");
filesdv[15].setUint32(file.xdim, 128);
filesdv[15].setUint32(file.ydim,  128);
filesdv[15].setUint32(file.zdim,  51);
filesdv[15].setFloat32(file.half_xdim,64.0);
filesdv[15].setFloat32(file.half_ydim,64.0);
filesdv[15].setFloat32(file.half_zdim,25.5);
filesdv[15].setFloat32(file.minval,0.0);
filesdv[15].setFloat32(file.maxval,4294967295.0);
filesdv[15].setInt32(file.z_up,1);
filesdv[15].setFloat32(file.near_clip_plane,128.0);         // xdim
filesdv[15].setFloat32(file.far_clip_plane,(3.0 * 128.0));   // xdim
filesdv[15].setFloat32(file.distance_to_eye,(2.0 * 128.0));  // xdim
filesdv[15].setUint32(file.vizwoman_file,0);
filesdv[15].setUint32(file.packed_bytes,1);
filesdv[15].setUint32(file.n_timesteps,800);
filesdv[15].setFloat64(file.processed_minval,0.0);
filesdv[15].setFloat64(file.processed_maxval,4294967295.0);
filesdv[15].setUint32(file.logarithmic_colormap,0);
filesdv[15].setUint32(file.colormap,0);
filesdv[15].setUint32(file.transferfunc,0);
filesdv[15].setUint32(file.filesize, 3342336);
filesdv[15].setFloat32(file.init_alpha_m,0.7);
filesdv[15].setFloat32(file.init_alpha_e,INITIAL_ALPHA_EXP);
filesdv[15].setFloat32(file.init_level,4999.0);
filesdv[15].setFloat32(file.zscale,1.95/1.5);
filesdv[15].setInt32(file.baked_alpha,0);
filesdv[15].setInt32(file.secondary_filesize, 0);
filesdv[15].setInt32(file.offset, 0);
filesdv[15].setInt32(file.stride, 1);
filesdv[15].setFloat32(file.minlat,0.0);
filesdv[15].setFloat32(file.maxlot,1.0);
filesdv[15].setFloat32(file.minlon,0.0);
filesdv[15].setFloat32(file.maxlon,1.0);
filesdv[15].setFloat32(file.minz,0.0);
filesdv[15].setFloat32(file.maxz,1.0);
filesdv[15].setFloat32(file.delz,1.0);
filesdv[15].setFloat32(file.dell,1.0);


filesdv[16].setUint32(file.code, "GDR");
filesdv[16].setUint32(file.xdim, 204);
filesdv[16].setUint32(file.ydim,  121);
filesdv[16].setUint32(file.zdim,  67);
filesdv[16].setFloat32(file.half_xdim,101.5);
filesdv[16].setFloat32(file.half_ydim,60.0);
filesdv[16].setFloat32(file.half_zdim,33.0);
filesdv[16].setFloat32(file.minval,0.0);
filesdv[16].setFloat32(file.maxval,4294967295.0);
filesdv[16].setInt32(file.z_up,1);
filesdv[16].setFloat32(file.near_clip_plane,204.0);         // xdim
filesdv[16].setFloat32(file.far_clip_plane,(3.0 * 204.0));   // xdim
filesdv[16].setFloat32(file.distance_to_eye,(2.0 * 204.0));  // xdim
filesdv[16].setUint32(file.vizwoman_file,0);
filesdv[16].setUint32(file.packed_bytes,1);
filesdv[16].setUint32(file.n_timesteps,359);
filesdv[16].setFloat64(file.processed_minval,0.0);
filesdv[16].setFloat64(file.processed_maxval,4294967295.0);
filesdv[16].setUint32(file.logarithmic_colormap,0);
filesdv[16].setUint32(file.colormap,0);
filesdv[16].setUint32(file.transferfunc,0);
filesdv[16].setUint32(file.filesize, 6615312);
filesdv[16].setFloat32(file.init_alpha_m,0.7);
filesdv[16].setFloat32(file.init_alpha_e,INITIAL_ALPHA_EXP);
filesdv[16].setFloat32(file.init_level,4999.0);
filesdv[16].setFloat32(file.zscale,0.8);
filesdv[16].setInt32(file.baked_alpha,0);
filesdv[16].setInt32(file.secondary_filesize, 0);
filesdv[16].setInt32(file.offset, 0);
filesdv[16].setInt32(file.stride, 1);
filesdv[16].setFloat32(file.minlat,0.0);
filesdv[16].setFloat32(file.maxlot,1.0);
filesdv[16].setFloat32(file.minlon,0.0);
filesdv[16].setFloat32(file.maxlon,1.0);
filesdv[16].setFloat32(file.minz,0.0);
filesdv[16].setFloat32(file.maxz,1.0);
filesdv[16].setFloat32(file.delz,1.0);
filesdv[16].setFloat32(file.dell,1.0);



filesdv[17].setUint32(file.code, "H14");
filesdv[17].setUint32(file.xdim, 720);
filesdv[17].setUint32(file.ydim,  660);
filesdv[17].setUint32(file.zdim,  110);
filesdv[17].setFloat32(file.half_xdim,359.5);
filesdv[17].setFloat32(file.half_ydim,359.5);
filesdv[17].setFloat32(file.half_zdim,54.05);
filesdv[17].setFloat32(file.minval,0.0);
filesdv[17].setFloat32(file.maxval,0xffffffff);
filesdv[17].setInt32(file.z_up,1);
filesdv[17].setFloat32(file.near_clip_plane,720.0);         // xdim
filesdv[17].setFloat32(file.far_clip_plane,(3.0 * 720.0));   // xdim
filesdv[17].setFloat32(file.distance_to_eye,(2.0 * 720.0));  // xdim
filesdv[17].setUint32(file.vizwoman_file,0);
filesdv[17].setUint32(file.packed_bytes,1);
filesdv[17].setUint32(file.n_timesteps,10);
filesdv[17].setFloat64(file.processed_minval,0.0);
filesdv[17].setFloat64(file.processed_maxval,0xffffffff);
filesdv[17].setUint32(file.logarithmic_colormap,0);
filesdv[17].setUint32(file.colormap,0);
filesdv[17].setUint32(file.transferfunc,0);
filesdv[17].setUint32(file.filesize, 209088000);
filesdv[17].setFloat32(file.init_alpha_m,0.9);
filesdv[17].setFloat32(file.init_alpha_e,0.1);
filesdv[17].setFloat32(file.init_level, 4999.0);
filesdv[17].setFloat32(file.zscale,.8);
filesdv[17].setInt32(file.baked_alpha,0);
filesdv[17].setInt32(file.secondary_filesize, 386*12);
filesdv[17].setInt32(file.offset, 0);
filesdv[17].setInt32(file.stride, 1);
filesdv[17].setFloat32(file.minlat,18.104927);
filesdv[17].setFloat32(file.maxlot,34.944931);
filesdv[17].setFloat32(file.minlon,-98.088501);
filesdv[17].setFloat32(file.maxlon,-77.441956);
filesdv[17].setFloat32(file.minz,0.0);
filesdv[17].setFloat32(file.maxz,20000.0);
filesdv[17].setFloat32(file.delz,5000.0);
filesdv[17].setFloat32(file.dell,2.0);

filesdv[18].setUint32(file.code, "H25");
filesdv[18].setUint32(file.xdim, 720);
filesdv[18].setUint32(file.ydim,  660);
filesdv[18].setUint32(file.zdim,  110);
filesdv[18].setFloat32(file.half_xdim,359.5);
filesdv[18].setFloat32(file.half_ydim,359.5);
filesdv[18].setFloat32(file.half_zdim,54.5);
filesdv[18].setFloat32(file.minval,0.0);
filesdv[18].setFloat32(file.maxval,0xffffffff);
filesdv[18].setInt32(file.z_up,1);
filesdv[18].setFloat32(file.near_clip_plane,720.0);         // xdim
filesdv[18].setFloat32(file.far_clip_plane,(3.0 * 720.0));   // xdim
filesdv[18].setFloat32(file.distance_to_eye,(2.0 * 720.0));  // xdim
filesdv[18].setUint32(file.vizwoman_file,0);
filesdv[18].setUint32(file.packed_bytes,1);
filesdv[18].setUint32(file.n_timesteps,10);
filesdv[18].setFloat64(file.processed_minval,0.0);
filesdv[18].setFloat64(file.processed_maxval,0xffffffff);
filesdv[18].setUint32(file.logarithmic_colormap,0);
filesdv[18].setUint32(file.colormap,0);
filesdv[18].setUint32(file.transferfunc,0);
filesdv[18].setUint32(file.filesize, 209088000);
filesdv[18].setFloat32(file.init_alpha_m,0.9);
filesdv[18].setFloat32(file.init_alpha_e,0.1);
filesdv[18].setFloat32(file.init_level, 4999.0);
filesdv[18].setFloat32(file.zscale,.8);
filesdv[18].setInt32(file.baked_alpha,0);
filesdv[18].setInt32(file.secondary_filesize, 386*12);
filesdv[18].setInt32(file.offset, 0);
filesdv[18].setInt32(file.stride, 1);
filesdv[18].setFloat32(file.minlat,18.104927);
filesdv[18].setFloat32(file.maxlot,34.944931);
filesdv[18].setFloat32(file.minlon,-98.088501);
filesdv[18].setFloat32(file.maxlon,-77.441956);
filesdv[18].setFloat32(file.minz,0.0);
filesdv[18].setFloat32(file.maxz,20000.0);
filesdv[18].setFloat32(file.delz,5000.0);
filesdv[18].setFloat32(file.dell,2.0);

filesdv[19].setUint32(file.code, "H36");
filesdv[19].setUint32(file.xdim, 720);
filesdv[19].setUint32(file.ydim,  660);
filesdv[19].setUint32(file.zdim,  110);
filesdv[19].setFloat32(file.half_xdim,359.5);
filesdv[19].setFloat32(file.half_ydim,359.5);
filesdv[19].setFloat32(file.half_zdim,54.05);
filesdv[19].setFloat32(file.minval,0.0);
filesdv[19].setFloat32(file.maxval,0xffffffff);
filesdv[19].setInt32(file.z_up,1);
filesdv[19].setFloat32(file.near_clip_plane,720.0);         // xdim
filesdv[19].setFloat32(file.far_clip_plane,(3.0 * 720.0));   // xdim
filesdv[19].setFloat32(file.distance_to_eye,(2.0 * 720.0));  // xdim
filesdv[19].setUint32(file.vizwoman_file,0);
filesdv[19].setUint32(file.packed_bytes,1);
filesdv[19].setUint32(file.n_timesteps,10);
filesdv[19].setFloat64(file.processed_minval,0.0);
filesdv[19].setFloat64(file.processed_maxval,0xffffffff);
filesdv[19].setUint32(file.logarithmic_colormap,0);
filesdv[19].setUint32(file.colormap,0);
filesdv[19].setUint32(file.transferfunc,0);
filesdv[19].setUint32(file.filesize, 209088000);
filesdv[19].setFloat32(file.init_alpha_m,0.9);
filesdv[19].setFloat32(file.init_alpha_e,0.1);
filesdv[19].setFloat32(file.init_level, 4999.0);
filesdv[19].setFloat32(file.zscale,.8);
filesdv[19].setInt32(file.baked_alpha,0);
filesdv[19].setInt32(file.secondary_filesize, 386*12);
filesdv[19].setInt32(file.offset, 0);
filesdv[19].setInt32(file.stride, 1);
filesdv[19].setFloat32(file.minlat,18.104927);
filesdv[19].setFloat32(file.maxlot,34.944931);
filesdv[19].setFloat32(file.minlon,-98.088501);
filesdv[19].setFloat32(file.maxlon,-77.441956);
filesdv[19].setFloat32(file.minz,0.0);
filesdv[19].setFloat32(file.maxz,20000.0);
filesdv[19].setFloat32(file.delz,5000.0);
filesdv[19].setFloat32(file.dell,2.0);

filesdv[20].setUint32(file.code, "HAR");
filesdv[20].setUint32(file.xdim, 720);
filesdv[20].setUint32(file.ydim,  660);
filesdv[20].setUint32(file.zdim,  110);
filesdv[20].setFloat32(file.half_xdim,359.5);
filesdv[20].setFloat32(file.half_ydim,329.5);
filesdv[20].setFloat32(file.half_zdim,54.05);
filesdv[20].setFloat32(file.minval,-25.01);
filesdv[20].setFloat32(file.maxval,60.66);
filesdv[20].setInt32(file.z_up,1);
filesdv[20].setFloat32(file.near_clip_plane,720.0);         // xdim
filesdv[20].setFloat32(file.far_clip_plane,(3.0 * 720.0));   // xdim
filesdv[20].setFloat32(file.distance_to_eye,(2.0 * 720.0));  // xdim
filesdv[20].setUint32(file.vizwoman_file,0);
filesdv[20].setUint32(file.packed_bytes,0);
filesdv[20].setUint32(file.n_timesteps,10);
filesdv[20].setFloat64(file.processed_minval,1000.0);
filesdv[20].setFloat64(file.processed_maxval,5000.0);
filesdv[20].setUint32(file.logarithmic_colormap,0);
filesdv[20].setUint32(file.colormap,0);
filesdv[20].setUint32(file.transferfunc,0);
filesdv[20].setUint32(file.filesize, 209088000);
filesdv[20].setFloat32(file.init_alpha_m,0.8);
filesdv[20].setFloat32(file.init_alpha_e,INITIAL_ALPHA_EXP);
filesdv[20].setFloat32(file.init_level, 4999.0);
filesdv[20].setFloat32(file.zscale,.8);
filesdv[20].setInt32(file.baked_alpha,0);
filesdv[20].setInt32(file.secondary_filesize, 0);
filesdv[20].setInt32(file.offset, 0);
filesdv[20].setInt32(file.stride, 1);
filesdv[20].setFloat32(file.minlat,18.104927);
filesdv[20].setFloat32(file.maxlot,34.944931);
filesdv[20].setFloat32(file.minlon,-98.088501);
filesdv[20].setFloat32(file.maxlon,-77.441956);
filesdv[20].setFloat32(file.minz,0.0);
filesdv[20].setFloat32(file.maxz,20000.0);
filesdv[20].setFloat32(file.delz,5000.0);
filesdv[20].setFloat32(file.dell,2.0);

filesdv[21].setUint32(file.code, "HAS");
filesdv[21].setUint32(file.xdim, 720);
filesdv[21].setUint32(file.ydim,  660);
filesdv[21].setUint32(file.zdim,  110);
filesdv[21].setFloat32(file.half_xdim,359.5);
filesdv[21].setFloat32(file.half_ydim,329.5);
filesdv[21].setFloat32(file.half_zdim,54.05);
filesdv[21].setFloat32(file.minval,0.0);
filesdv[21].setFloat32(file.maxval,76.03);
filesdv[21].setInt32(file.z_up,1);
filesdv[21].setFloat32(file.near_clip_plane,720.0);         // xdim
filesdv[21].setFloat32(file.far_clip_plane,(3.0 * 720.0));   // xdim
filesdv[21].setFloat32(file.distance_to_eye,(2.0 * 720.0));  // xdim
filesdv[21].setUint32(file.vizwoman_file,0);
filesdv[21].setUint32(file.packed_bytes,0);
filesdv[21].setUint32(file.n_timesteps,10);
filesdv[21].setFloat64(file.processed_minval,1000.0);
filesdv[21].setFloat64(file.processed_maxval,5000.0);
filesdv[21].setUint32(file.logarithmic_colormap,0);
filesdv[21].setUint32(file.colormap,0);
filesdv[21].setUint32(file.transferfunc,0);
filesdv[21].setUint32(file.filesize, 209088000);
filesdv[21].setFloat32(file.init_alpha_m,0.8);
filesdv[21].setFloat32(file.init_alpha_e,INITIAL_ALPHA_EXP);
filesdv[21].setFloat32(file.init_level, 4999.0);
filesdv[21].setFloat32(file.zscale,.8);
filesdv[21].setInt32(file.baked_alpha,0);
filesdv[21].setInt32(file.secondary_filesize, 0);
filesdv[21].setInt32(file.offset, 0);
filesdv[21].setInt32(file.stride, 1);
filesdv[21].setFloat32(file.minlat,18.104927);
filesdv[21].setFloat32(file.maxlot,34.944931);
filesdv[21].setFloat32(file.minlon,-98.088501);
filesdv[21].setFloat32(file.maxlon,-77.441956);
filesdv[21].setFloat32(file.minz,0.0);
filesdv[21].setFloat32(file.maxz,20000.0);
filesdv[21].setFloat32(file.delz,5000.0);
filesdv[21].setFloat32(file.dell,2.0);

filesdv[22].setUint32(file.code, "HAM");
filesdv[22].setUint32(file.xdim, 720);
filesdv[22].setUint32(file.ydim,  660);
filesdv[22].setUint32(file.zdim,  110);
filesdv[22].setFloat32(file.half_xdim,359.5);
filesdv[22].setFloat32(file.half_ydim,329.5);
filesdv[22].setFloat32(file.half_zdim,54.5);
filesdv[22].setFloat32(file.minval,-0.000001);
filesdv[22].setFloat32(file.maxval,0.004117);
filesdv[22].setInt32(file.z_up,1);
filesdv[22].setFloat32(file.near_clip_plane,720.0);         // xdim
filesdv[22].setFloat32(file.far_clip_plane,(3.0 * 720.0));   // xdim
filesdv[22].setFloat32(file.distance_to_eye,(2.0 * 720.0));  // xdim
filesdv[22].setUint32(file.vizwoman_file,0);
filesdv[22].setUint32(file.packed_bytes,0);
filesdv[22].setUint32(file.n_timesteps,57);
filesdv[22].setFloat64(file.processed_minval,1000.0);
filesdv[22].setFloat64(file.processed_maxval,5000.0);
filesdv[22].setUint32(file.logarithmic_colormap,0);
filesdv[22].setUint32(file.colormap,5);
filesdv[22].setUint32(file.transferfunc,0);
filesdv[22].setUint32(file.filesize, 209088000);
filesdv[22].setFloat32(file.init_alpha_m,0.8);
filesdv[22].setFloat32(file.init_alpha_e,INITIAL_ALPHA_EXP);
filesdv[22].setFloat32(file.init_level, 4999.0);
filesdv[22].setFloat32(file.zscale,.8);
filesdv[22].setInt32(file.baked_alpha,0);
filesdv[22].setInt32(file.secondary_filesize, 0);
filesdv[22].setInt32(file.offset, 0);
filesdv[22].setInt32(file.stride, 1);
filesdv[22].setFloat32(file.minlat,18.104927);
filesdv[22].setFloat32(file.maxlot,34.944931);
filesdv[22].setFloat32(file.minlon,-98.088501);
filesdv[22].setFloat32(file.maxlon,-77.441956);
filesdv[22].setFloat32(file.minz,0.0);
filesdv[22].setFloat32(file.maxz,20000.0);
filesdv[22].setFloat32(file.delz,5000.0);
filesdv[22].setFloat32(file.dell,2.0);

filesdv[23].setUint32(file.code, "H14_R");
filesdv[23].setUint32(file.xdim, 720);
filesdv[23].setUint32(file.ydim,  660);
filesdv[23].setUint32(file.zdim,  110);
filesdv[23].setFloat32(file.half_xdim,359.5);
filesdv[23].setFloat32(file.half_ydim,329.5);
filesdv[23].setFloat32(file.half_zdim,54.5);
filesdv[23].setFloat32(file.minval,0.0);
filesdv[23].setFloat32(file.maxval,0xffffffff);
filesdv[23].setInt32(file.z_up,1);
filesdv[23].setFloat32(file.near_clip_plane,720.0);         // xdim
filesdv[23].setFloat32(file.far_clip_plane,(3.0 * 720.0));   // xdim
filesdv[23].setFloat32(file.distance_to_eye,(2.0 * 720.0));  // xdim
filesdv[23].setUint32(file.vizwoman_file,0);
filesdv[23].setUint32(file.packed_bytes,1);
filesdv[23].setUint32(file.n_timesteps,72);
filesdv[23].setFloat64(file.processed_minval,0.0);
filesdv[23].setFloat64(file.processed_maxval,0xffffffff);
filesdv[23].setUint32(file.logarithmic_colormap,0);
filesdv[23].setUint32(file.colormap,0);
filesdv[23].setUint32(file.transferfunc,0);
filesdv[23].setUint32(file.filesize, 209088000);
filesdv[23].setFloat32(file.init_alpha_m,0.8);
filesdv[23].setFloat32(file.init_alpha_e,INITIAL_ALPHA_EXP);
filesdv[23].setFloat32(file.init_level, 4999.0);
filesdv[23].setFloat32(file.zscale,.8);
filesdv[23].setInt32(file.baked_alpha,0);
filesdv[23].setInt32(file.secondary_filesize, 386*12);
filesdv[23].setInt32(file.offset, 0);
filesdv[23].setInt32(file.stride, 1);
filesdv[23].setFloat32(file.minlat,18.104927);
filesdv[23].setFloat32(file.maxlot,34.944931);
filesdv[23].setFloat32(file.minlon,-98.088501);
filesdv[23].setFloat32(file.maxlon,-77.441956);
filesdv[23].setFloat32(file.minz,0.0);
filesdv[23].setFloat32(file.maxz,20000.0);
filesdv[23].setFloat32(file.delz,5000.0);
filesdv[23].setFloat32(file.dell,2.0);

filesdv[24].setUint32(file.code, "H25_R");
filesdv[24].setUint32(file.xdim, 720);
filesdv[24].setUint32(file.ydim,  660);
filesdv[24].setUint32(file.zdim,  110);
filesdv[24].setFloat32(file.half_xdim,359.5);
filesdv[24].setFloat32(file.half_ydim,329.5);
filesdv[24].setFloat32(file.half_zdim,54.5);
filesdv[24].setFloat32(file.minval,0.0);
filesdv[24].setFloat32(file.maxval,0xffffffff);
filesdv[24].setInt32(file.z_up,1);
filesdv[24].setFloat32(file.near_clip_plane,720.0);         // xdim
filesdv[24].setFloat32(file.far_clip_plane,(3.0 * 720.0));   // xdim
filesdv[24].setFloat32(file.distance_to_eye,(2.0 * 720.0));  // xdim
filesdv[24].setUint32(file.vizwoman_file,0);
filesdv[24].setUint32(file.packed_bytes,1);
filesdv[24].setUint32(file.n_timesteps,72);
filesdv[24].setFloat64(file.processed_minval,0.0);
filesdv[24].setFloat64(file.processed_maxval,0xffffffff);
filesdv[24].setUint32(file.logarithmic_colormap,0);
filesdv[24].setUint32(file.colormap,0);
filesdv[24].setUint32(file.transferfunc,0);
filesdv[24].setUint32(file.filesize, 209088000);
filesdv[24].setFloat32(file.init_alpha_m,0.8);
filesdv[24].setFloat32(file.init_alpha_e,INITIAL_ALPHA_EXP);
filesdv[24].setFloat32(file.init_level, 4999.0);
filesdv[24].setFloat32(file.zscale,.8);
filesdv[24].setInt32(file.baked_alpha,0);
filesdv[24].setInt32(file.secondary_filesize, 386*12);
filesdv[24].setInt32(file.offset, 0);
filesdv[24].setInt32(file.stride, 1);
filesdv[24].setFloat32(file.minlat,18.104927);
filesdv[24].setFloat32(file.maxlot,34.944931);
filesdv[24].setFloat32(file.minlon,-98.088501);
filesdv[24].setFloat32(file.maxlon,-77.441956);
filesdv[24].setFloat32(file.minz,0.0);
filesdv[24].setFloat32(file.maxz,20000.0);
filesdv[24].setFloat32(file.delz,5000.0);
filesdv[24].setFloat32(file.dell,2.0);

filesdv[25].setUint32(file.code, "H36_R");
filesdv[25].setUint32(file.xdim, 720);
filesdv[25].setUint32(file.ydim,  660);
filesdv[25].setUint32(file.zdim,  110);
filesdv[25].setFloat32(file.half_xdim,359.5);
filesdv[25].setFloat32(file.half_ydim,329.5);
filesdv[25].setFloat32(file.half_zdim,54.5);
filesdv[25].setFloat32(file.minval,0.0);
filesdv[25].setFloat32(file.maxval,0xffffffff);
filesdv[25].setInt32(file.z_up,1);
filesdv[25].setFloat32(file.near_clip_plane,720.0);         // xdim
filesdv[25].setFloat32(file.far_clip_plane,(3.0 * 720.0));   // xdim
filesdv[25].setFloat32(file.distance_to_eye,(2.0 * 720.0));  // xdim
filesdv[25].setUint32(file.vizwoman_file,0);
filesdv[25].setUint32(file.packed_bytes,1);
filesdv[25].setUint32(file.n_timesteps,72);
filesdv[25].setFloat64(file.processed_minval,0.0);
filesdv[25].setFloat64(file.processed_maxval,0xffffffff);
filesdv[25].setUint32(file.logarithmic_colormap,0);
filesdv[25].setUint32(file.colormap,0);
filesdv[25].setUint32(file.transferfunc,0);
filesdv[25].setUint32(file.filesize, 209088000);
filesdv[25].setFloat32(file.init_alpha_m,0.8);
filesdv[25].setFloat32(file.init_alpha_e,INITIAL_ALPHA_EXP);
filesdv[25].setFloat32(file.init_level, 4999.0);
filesdv[25].setFloat32(file.zscale,.8);
filesdv[25].setInt32(file.baked_alpha,0);
filesdv[25].setInt32(file.secondary_filesize, 386*12);
filesdv[25].setInt32(file.offset, 0);
filesdv[25].setInt32(file.stride, 1);
filesdv[25].setFloat32(file.minlat,18.104927);
filesdv[25].setFloat32(file.maxlot,34.944931);
filesdv[25].setFloat32(file.minlon,-98.088501);
filesdv[25].setFloat32(file.maxlon,-77.441956);
filesdv[25].setFloat32(file.minz,0.0);
filesdv[25].setFloat32(file.maxz,20000.0);
filesdv[25].setFloat32(file.delz,5000.0);
filesdv[25].setFloat32(file.dell,2.0);

filesdv[26].setUint32(file.code, "HAR_R");
filesdv[26].setUint32(file.xdim, 720);
filesdv[26].setUint32(file.ydim,  660);
filesdv[26].setUint32(file.zdim,  110);
filesdv[26].setFloat32(file.half_xdim,359.5);
filesdv[26].setFloat32(file.half_ydim,329.5);
filesdv[26].setFloat32(file.half_zdim,54.5);
filesdv[26].setFloat32(file.minval,-35.01);
filesdv[26].setFloat32(file.maxval,60.66);
filesdv[26].setInt32(file.z_up,1);
filesdv[26].setFloat32(file.near_clip_plane,720.0);         // xdim
filesdv[26].setFloat32(file.far_clip_plane,(3.0 * 720.0));   // xdim
filesdv[26].setFloat32(file.distance_to_eye,(2.0 * 720.0));  // xdim
filesdv[26].setUint32(file.vizwoman_file,0);
filesdv[26].setUint32(file.packed_bytes,0);
filesdv[26].setUint32(file.n_timesteps,72);
filesdv[26].setFloat64(file.processed_minval,1000.0);
filesdv[26].setFloat64(file.processed_maxval,5000.0);
filesdv[26].setUint32(file.logarithmic_colormap,0);
filesdv[26].setUint32(file.colormap,5);
filesdv[26].setUint32(file.transferfunc,0);
filesdv[26].setUint32(file.filesize, 209088000);
filesdv[26].setFloat32(file.init_alpha_m,0.1);
filesdv[26].setFloat32(file.init_alpha_e,INITIAL_ALPHA_EXP);
filesdv[26].setFloat32(file.init_level, 4999.0);
filesdv[26].setFloat32(file.zscale,.8);
filesdv[26].setInt32(file.baked_alpha,0);
filesdv[26].setInt32(file.secondary_filesize, 386*12);
filesdv[26].setInt32(file.offset, 0);
filesdv[26].setInt32(file.stride, 1);
filesdv[26].setFloat32(file.minlat,18.104927);
filesdv[26].setFloat32(file.maxlot,34.944931);
filesdv[26].setFloat32(file.minlon,-98.088501);
filesdv[26].setFloat32(file.maxlon,-77.441956);
filesdv[26].setFloat32(file.minz,0.0);
filesdv[26].setFloat32(file.maxz,20000.0);
filesdv[26].setFloat32(file.delz,5000.0);
filesdv[26].setFloat32(file.dell,2.0);

filesdv[27].setUint32(file.code, "HAS_R");
filesdv[27].setUint32(file.xdim, 720);
filesdv[27].setUint32(file.ydim,  660);
filesdv[27].setUint32(file.zdim,  110);
filesdv[27].setFloat32(file.half_xdim,359.5);
filesdv[27].setFloat32(file.half_ydim,329.5);
filesdv[27].setFloat32(file.half_zdim,54.5);
filesdv[27].setFloat32(file.minval,0.0);
filesdv[27].setFloat32(file.maxval,76.03);
filesdv[27].setInt32(file.z_up,1);
filesdv[27].setFloat32(file.near_clip_plane,720.0);         // xdim
filesdv[27].setFloat32(file.far_clip_plane,(3.0 * 720.0));   // xdim
filesdv[27].setFloat32(file.distance_to_eye,(2.0 * 720.0));  // xdim
filesdv[27].setUint32(file.vizwoman_file,0);
filesdv[27].setUint32(file.packed_bytes,0);
filesdv[27].setUint32(file.n_timesteps,72);
filesdv[27].setFloat64(file.processed_minval,1000.0);
filesdv[27].setFloat64(file.processed_maxval,5000.0);
filesdv[27].setUint32(file.logarithmic_colormap,0);
filesdv[27].setUint32(file.colormap,5);
filesdv[27].setUint32(file.transferfunc,0);
filesdv[27].setUint32(file.filesize, 209088000);
filesdv[27].setFloat32(file.init_alpha_m,0.1);
filesdv[27].setFloat32(file.init_alpha_e,INITIAL_ALPHA_EXP);
filesdv[27].setFloat32(file.init_level, 4999.0);
filesdv[27].setFloat32(file.zscale,.8);
filesdv[27].setInt32(file.baked_alpha,0);
filesdv[27].setInt32(file.secondary_filesize, 386*12);
filesdv[27].setInt32(file.offset, 0);
filesdv[27].setInt32(file.stride, 1);
filesdv[27].setFloat32(file.minlat,18.104927);
filesdv[27].setFloat32(file.maxlot,34.944931);
filesdv[27].setFloat32(file.minlon,-98.088501);
filesdv[27].setFloat32(file.maxlon,-77.441956);
filesdv[27].setFloat32(file.minz,0.0);
filesdv[27].setFloat32(file.maxz,20000.0);
filesdv[27].setFloat32(file.delz,5000.0);
filesdv[27].setFloat32(file.dell,2.0);

filesdv[28].setUint32(file.code, "HAM_R");
filesdv[28].setUint32(file.xdim, 720);
filesdv[28].setUint32(file.ydim,  660);
filesdv[28].setUint32(file.zdim,  110);
filesdv[28].setFloat32(file.half_xdim,359.5);
filesdv[28].setFloat32(file.half_ydim,329.5);
filesdv[28].setFloat32(file.half_zdim,54.5);
filesdv[28].setFloat32(file.minval,-0.000001);
filesdv[28].setFloat32(file.maxval,0.004117);
filesdv[28].setInt32(file.z_up,1);
filesdv[28].setFloat32(file.near_clip_plane,720.0);         // xdim
filesdv[28].setFloat32(file.far_clip_plane,(3.0 * 720.0));   // xdim
filesdv[28].setFloat32(file.distance_to_eye,(2.0 * 720.0));  // xdim
filesdv[28].setUint32(file.vizwoman_file,0);
filesdv[28].setUint32(file.packed_bytes,0);
filesdv[28].setUint32(file.n_timesteps,72);
filesdv[28].setFloat64(file.processed_minval,1000.0);
filesdv[28].setFloat64(file.processed_maxval,5000.0);
filesdv[28].setUint32(file.logarithmic_colormap,0);
filesdv[28].setUint32(file.colormap,5);
filesdv[28].setUint32(file.transferfunc,0);
filesdv[28].setUint32(file.filesize, 209088000);
filesdv[28].setFloat32(file.init_alpha_m,0.1);
filesdv[28].setFloat32(file.init_alpha_e,INITIAL_ALPHA_EXP);
filesdv[28].setFloat32(file.init_level, 4999.0);
filesdv[28].setFloat32(file.zscale,.8);
filesdv[28].setInt32(file.baked_alpha,0);
filesdv[28].setInt32(file.secondary_filesize, 386*12);
filesdv[28].setInt32(file.offset, 0);
filesdv[28].setInt32(file.stride, 1);
filesdv[28].setFloat32(file.minlat,18.104927);
filesdv[28].setFloat32(file.maxlot,34.944931);
filesdv[28].setFloat32(file.minlon,-98.088501);
filesdv[28].setFloat32(file.maxlon,-77.441956);
filesdv[28].setFloat32(file.minz,0.0);
filesdv[28].setFloat32(file.maxz,20000.0);
filesdv[28].setFloat32(file.delz,5000.0);
filesdv[28].setFloat32(file.dell,2.0);


var clientstate = {
	bbox: 0,
	grid: 0,
	light: 1,
	auto_surface: 0,
	connected: 1,
	init:	1,
	animate: 0,
	changed: true,
	anmslice: [0, 0, 0],
	select_flag: 1,
	surface_select_flag: 0,
	fileidx:	DEFAULTIDX,
	typeidx:	0,
	dyeidx:	0
};

var statebuffer = new ArrayBuffer(UPDATEPACKETSIZE);
var UP = new DataView(statebuffer);

function initStatePacket() {
   
   for (j = 0; j < num_media; ++j) {
      /*if (checking for null filecodes ) {
		check filecodes when you read in cmd line params not here.
      }
	  */

      for (i = 0; i < NUM_FILEPACKETS; i++) {
         if (filecodes[j].toUpperCase() ===  models[i].toUpperCase()) {
            UP.setUint32(state.data_fileindex+j*4, i);
         }
      }
   }

   for (i=0; i<num_media; ++i) FPP[i] = UP.getUint32(state.data_fileindex+i*4);;
   for (i=1; i<num_media; ++i) {
      if (filesdv[FPP[0]].getUint32(file.n_timesteps) != filesdv[FPP[i]].getUint32(file.n_timesteps)) {
         console.log("n_timesteps differs between files");
      }
      if (filesdv[FPP[0]].getUint32(file.xdim) != filesdv[FPP[i]].getUint32(file.xdim)) {
         console.log("xdim differs between files\n");
      }
      if (filesdv[FPP[0]].getUint32(file.ydim) != filesdv[FPP[i]].getUint32(file.ydim)) {
         console.log("ydim differs between files\n");
      }
      if (filesdv[FPP[0]].getUint32(file.zdim) != filesdv[FPP[i]].getUint32(file.zdim)) {
         console.log("zdim differs between files\n");
      }
      if (filesdv[FPP[0]].getFloat32(file.zscale) != filesdv[FPP[i]].getFloat32(file.zscale)) {
         console.log("zscale differs between files\n");
      }
   }
   if (num_media > 1) for (i=0; i<num_media; ++i) {
      if (filesdv[FPP[0]].getUint32(file.z_up) != 1) {
         console.log("z_up must be 1 with multiple files\n");
      }
   }

   UP.setUint32(state.timestep,1);
   clientstate.animate = (filesdv[FPP[0]].getUint32(file.n_timesteps) > 1) ? 1 : 0;
   clientstate.anmslice[0] = clientstate.anmslice[1] = clientstate.anmslice[2] = 0;
   selected_medium = 0;
   UP.setUint32(state.num_media, num_media);
   for (i=0; i<num_media; ++i) {
		UP.setFloat64(state.levelval+(i*8),filesdv[FPP[i]].getFloat32(file.init_level));         
	}
   for (i=0; i<num_media; ++i) UP.setFloat32(state.alpha_m + (i*4),filesdv[FPP[i]].getFloat32(file.init_alpha_m));
   for (i=0; i<num_media; ++i) UP.setFloat32(state.alpha_e + (i*4),filesdv[FPP[i]].getFloat32(file.init_alpha_e));
   for (i=0; i<num_media; ++i) UP.setFloat32(state.deltasample + (i*4),1.0/1600.0);
   UP.setUint32(state.wid_rounded_to_tile, VPWIDTH);
   UP.setUint32(state.hgt_rounded_to_tile, VPHEIGHT);
   UP.setUint32(state.killswitch, 0);
   UP.setUint32(state.vpchange, 0);
   UP.setFloat32(state.view_clipplane, 0.525 * filesdv[FPP[0]].getFloat32(file.distance_to_eye));
   UP.setFloat32(state.view_clipplane+4, 1.475* filesdv[FPP[0]].getFloat32(file.distance_to_eye));
   UP.setUint32(state.display, 1);
   UP.setUint32(state.display+4, 1);
   UP.setUint32(state.display+8, 1);
   UP.setUint32(state.lighting_enabled, 1);
   UP.setUint32(state.auto_surface, 0);

   if (filesdv[FPP[0]].getUint32(file.n_timesteps) > 1)
      UP.setFloat32(state.fovy, 23.0); // 7.2f;
   else 
      UP.setFloat32(state.fovy, 20.0);

	// should I be setting clientstate.fileidx to FPP[0] initially??
	clientstate.fileidx = FPP[0];
	UP.setFloat32(state.cutplane, -filesdv[clientstate.fileidx].getFloat32(file.half_xdim));
    UP.setFloat32(state.cutplane+4, filesdv[clientstate.fileidx].getFloat32(file.half_xdim));
    UP.setFloat32(state.cutplane+8, -filesdv[clientstate.fileidx].getFloat32(file.half_ydim));
    UP.setFloat32(state.cutplane+12, filesdv[clientstate.fileidx].getFloat32(file.half_ydim));
    UP.setFloat32(state.cutplane+16, filesdv[clientstate.fileidx].getFloat32(file.half_zdim));
    UP.setFloat32(state.cutplane+20, -filesdv[clientstate.fileidx].getFloat32(file.half_zdim));

    if (FLIPZ) {
    	UP.setFloat32(state.cutplane+16,  (filesdv[FPP[0]].getFloat32(file.half_zdim) *  num_media));
    	UP.setFloat32(state.cutplane+20, -(filesdv[FPP[0]].getFloat32(file.half_zdim) * num_media));
	}
    else {	
    	UP.setFloat32(state.cutplane+16,-(filesdv[FPP[0]].getFloat32(file.half_zdim) * num_media));
    	UP.setFloat32(state.cutplane+20,(filesdv[FPP[0]].getFloat32(file.half_zdim) * num_media));
	}

    UP.setFloat32(state.center, 0.5 * (UP.getFloat32(state.cutplane) + UP.getFloat32(state.cutplane+4)));
    UP.setFloat32(state.center, 0.5 * (UP.getFloat32(state.cutplane+8) + UP.getFloat32(state.cutplane+12)));
    UP.setFloat32(state.center, 0.5 * (UP.getFloat32(state.cutplane+16) + UP.getFloat32(state.cutplane+20)));

    pointsz = UP.getUint32(state.fileindex) ? 3 : 1;
    UP.setUint32(state.pointsize, pointsz);
    UP.setUint32(state.vpchange, 1);
    UP.setUint32(state.cellsize, 1);
    UP.setInt32(state.timestep, 1);
    UP.setInt32(state.n_timesteps_available,filesdv[clientstate.fileidx].getUint32(file.n_timesteps));
    UP.setFloat32(state.zscale, filesdv[clientstate.fileidx].getFloat32(file.zscale));
	UP.setFloat32(state.select_target, 1);


    UP.setUint32(state.select_state, 0);
    UP.setUint32(state.select_x, 0);
    UP.setUint32(state.select_y, 0);

    surface_select_flag = 0;
	select_flag = 0;
	console.log("DONE with INIT\n");
}

function updateProjection(matrix) {
	UP.setFloat32(state.projection_matrix,matrix[0]);
	UP.setFloat32(state.projection_matrix+4,matrix[1]);
	UP.setFloat32(state.projection_matrix+8,matrix[2]);
	UP.setFloat32(state.projection_matrix+12,matrix[3]);
	UP.setFloat32(state.projection_matrix+16,matrix[4]);
	UP.setFloat32(state.projection_matrix+20,matrix[5]);
	UP.setFloat32(state.projection_matrix+24,matrix[6]);
	UP.setFloat32(state.projection_matrix+28,matrix[7]);
	UP.setFloat32(state.projection_matrix+32,matrix[8]);
	UP.setFloat32(state.projection_matrix+36,matrix[9]);
	UP.setFloat32(state.projection_matrix+40,matrix[10]);
	UP.setFloat32(state.projection_matrix+44,matrix[11]);
	UP.setFloat32(state.projection_matrix+48,matrix[12]);
	UP.setFloat32(state.projection_matrix+52,matrix[13]);
	UP.setFloat32(state.projection_matrix+56,matrix[14]);
	UP.setFloat32(state.projection_matrix+60,matrix[15]);
}

function updateModelView(matrix) {
	UP.setFloat32(state.modelview_matrix,matrix[0]);
	UP.setFloat32(state.modelview_matrix+4,matrix[1]);
	UP.setFloat32(state.modelview_matrix+8,matrix[2]);
	UP.setFloat32(state.modelview_matrix+12,matrix[3]);
	UP.setFloat32(state.modelview_matrix+16,matrix[4]);
	UP.setFloat32(state.modelview_matrix+20,matrix[5]);
	UP.setFloat32(state.modelview_matrix+24,matrix[6]);
	UP.setFloat32(state.modelview_matrix+28,matrix[7]);
	UP.setFloat32(state.modelview_matrix+32,matrix[8]);
	UP.setFloat32(state.modelview_matrix+36,matrix[9]);
	UP.setFloat32(state.modelview_matrix+40,matrix[10]);
	UP.setFloat32(state.modelview_matrix+44,matrix[11]);
	UP.setFloat32(state.modelview_matrix+48,matrix[12]);
	UP.setFloat32(state.modelview_matrix+52,matrix[13]);
	UP.setFloat32(state.modelview_matrix+56,matrix[14]);
	UP.setFloat32(state.modelview_matrix+60,matrix[15]);
}

function printFloat32Matrix(offset) {
	console.log("%f, %f, %f, %f", UP.getFloat32(offset),UP.getFloat32(offset+4),UP.getFloat32(offset+8),UP.getFloat32(offset+12));
	console.log("%f, %f, %f, %f", UP.getFloat32(offset+16),UP.getFloat32(offset+20),UP.getFloat32(offset+24),UP.getFloat32(offset+28)); 
    console.log("%f, %f, %f, %f", UP.getFloat32(offset+32),UP.getFloat32(offset+36),UP.getFloat32(offset+40),UP.getFloat32(offset+44));
	console.log("%f, %f, %f, %f", UP.getFloat32(offset+48),UP.getFloat32(offset+52),UP.getFloat32(offset+56),UP.getFloat32(offset+60));
}


function printServerState() {
	console.log("level=%f",UP.getFloat64(state.levelval));
	console.log("file=%d",UP.getUint32(state.data_fileindex));
	console.log("wid_rnd_to_tile=%d",UP.getUint32(state.wid_rounded_to_tile));
	console.log("hgt_rnd_to_tile=%d",UP.getUint32(state.hgt_rounded_to_tile));
	console.log("killstch=%d",UP.getUint32(state.killswitch));
	console.log("vpchange=%d",UP.getUint32(state.vpchange));
	console.log("center[0]=%f",UP.getFloat32(state.center));
	console.log("center[1]=%f",UP.getFloat32(state.center+4));
	console.log("center[2]=%f",UP.getFloat32(state.center+8));
	console.log("media_offset=%d",UP.getUint32(state.media_offset));
	console.log("alpham=%f",UP.getFloat32(state.alpha_m));
	console.log("alphae=%f",UP.getFloat32(state.alpha_e));
	console.log("fovy=%f",UP.getFloat32(state.fovy));
	console.log("viewclip[0]=%f",UP.getFloat32(state.view_clipplane));
	console.log("viewclip[1]=%f",UP.getFloat32(state.view_clipplane+4));
	console.log("display[0]=%d",UP.getUint32(state.display));
	console.log("display[1]=%d",UP.getUint32(state.display+4));
	console.log("display[2]=%d",UP.getUint32(state.display+8));
	console.log("pointsize=%d",UP.getUint32(state.pointsize));
	console.log("lighting=%d",UP.getUint32(state.lighting_enabled));
	console.log("autosurf=%d",UP.getUint32(state.auto_surface));
	console.log("mvm[0]=%f",UP.getFloat32(state.modelview_matrix));
	console.log("mvm[1]=%f",UP.getFloat32(state.modelview_matrix+4));
	console.log("mvm[2]=%f",UP.getFloat32(state.modelview_matrix+8));
	console.log("mvm[3]=%f",UP.getFloat32(state.modelview_matrix+12));
	console.log("mvm[4]=%f",UP.getFloat32(state.modelview_matrix+16));
	console.log("mvm[5]=%f",UP.getFloat32(state.modelview_matrix+20));
	console.log("mvm[6]=%f",UP.getFloat32(state.modelview_matrix+24));
	console.log("mvm[7]=%f",UP.getFloat32(state.modelview_matrix+28));
	console.log("mvm[8]=%f",UP.getFloat32(state.modelview_matrix+32));
	console.log("mvm[9]=%f",UP.getFloat32(state.modelview_matrix+36));
	console.log("mvm[10]=%f",UP.getFloat32(state.modelview_matrix+40));
	console.log("mvm[11]=%f",UP.getFloat32(state.modelview_matrix+44));
	console.log("mvm[12]=%f",UP.getFloat32(state.modelview_matrix+48));
	console.log("mvm[13]=%f",UP.getFloat32(state.modelview_matrix+52));
	console.log("mvm[14]=%f",UP.getFloat32(state.modelview_matrix+56));
	console.log("mvm[15]=%f",UP.getFloat32(state.modelview_matrix+60));
	console.log("pm[0]=%f",UP.getFloat32(state.projection_matrix));
	console.log("pm[1]=%f",UP.getFloat32(state.projection_matrix+4));
	console.log("pm[2]=%f",UP.getFloat32(state.projection_matrix+8));
	console.log("pm[3]=%f",UP.getFloat32(state.projection_matrix+12));
	console.log("pm[4]=%f",UP.getFloat32(state.projection_matrix+16));
	console.log("pm[5]=%f",UP.getFloat32(state.projection_matrix+20));
	console.log("pm[6]=%f",UP.getFloat32(state.projection_matrix+24));
	console.log("pm[7]=%f",UP.getFloat32(state.projection_matrix+28));
	console.log("pm[8]=%f",UP.getFloat32(state.projection_matrix+32));
	console.log("pm[9]=%f",UP.getFloat32(state.projection_matrix+36));
	console.log("pm[10]=%f",UP.getFloat32(state.projection_matrix+40));
	console.log("pm[11]=%f",UP.getFloat32(state.projection_matrix+44));
	console.log("pm[12]=%f",UP.getFloat32(state.projection_matrix+48));
	console.log("pm[13]=%f",UP.getFloat32(state.projection_matrix+52));
	console.log("pm[14]=%f",UP.getFloat32(state.projection_matrix+56));
	console.log("pm[15]=%f",UP.getFloat32(state.projection_matrix+60));
	console.log("cutplane[0]=%f",UP.getFloat32(state.cutplane));
	console.log("cutplane[1]=%f",UP.getFloat32(state.cutplane+4));
	console.log("cutplane[2]=%f",UP.getFloat32(state.cutplane+8));
	console.log("cutplane[3]=%f",UP.getFloat32(state.cutplane+12));
	console.log("cutplane[4]=%f",UP.getFloat32(state.cutplane+16));
	console.log("cutplane[5]=%f",UP.getFloat32(state.cutplane+20));
	console.log("deltas=%f",UP.getFloat32(state.deltasample));
	console.log("cellsz=%d",UP.getUint32(state.cellsize));
	console.log("n_timesteps_available=%d",UP.getInt32(state.n_timesteps_available));
	console.log("timestep=%d",UP.getInt32(state.timestep));
	console.log("zscale=%f",UP.getFloat32(state.zscale));
}
