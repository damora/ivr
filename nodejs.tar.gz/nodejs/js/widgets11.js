/*global $, jQuery, console, statedata */

var cutx, cuty, cutz; 
var clip; 
var pointsz, pointlevel; 
var deltas;
var alphae, alpham; 
var timesteps; 

function initWidgets() {
	document.getElementById("animate").checked = (clientstate.animate === 1) ? true : false;
	document.getElementById("selecttype").checked = true;
	clientstate.surface_select_flag = true;
	document.getElementById("dyetype").checked = true;
	UP.setUint32(state.select_target, 1);
}

function getWidgetState(widget) {
}

var prec = function precision(data, value) {
	return data.toPrecision(value);
}
var exp = function exponential(data, value) {
	return data.toPrecision(value).toExponential();
}
function onoff(id){
  var  currentvalue = document.getElementById(id).value;
  if(currentvalue == "Off"){
    document.getElementById(id).value="On";
  }else{
    document.getElementById(id).value="Off";
  }
}

    $(function(){
    	var slider = $("#sidebar").slideReveal({
        position: "left",
        push:   false,
        width: 300,
        top: 30,
        autoescape: true,
        trigger: $(".handle"),
        shown: function(obj) {
            obj.find('.handle').html('<span class="glyphicon glyphicon-chevron-left"></span>');
        //  obj.addClass("left-shadow-overlay");
        },
        hidden: function(obj){
            obj.find('.handle').html('<span class="glyphicon glyphicon-chevron-right"></span>');
        //  obj.removeClass("left-shadow-overlay");
        },
    });
  });

  function updatevalue(val) {
    document.getElementById('textInput').value = val;
  }

  function getbox(box) {

	switch(box.id) {
		case "X":
			UP.setUint32(state.display, box.checked);
			break;
		case "Y":
			UP.setUint32(state.display+4, box.checked);
			break;
		case "Z":
			UP.setUint32(state.display+8, box.checked);
			break;
		case "animate":
			if (timestep > 0) {
		 		clientstate.animate ^= 1;
				if (clientstate.animate === 0) {
					console.log("drawScene set");
					cancelAnimationFrame(requestid);
		 			requestid= requestAnimationFrame(drawScene);
					serverneedsupdate = true;
				}
				else {
					console.log("animateScene set");
					cancelAnimationFrame(requestid);
					requestid = requestAnimationFrame(animateScene);
				}
			}
			break;
		case "depth":
			clientstate.surface_select_flag = 0;
			break;
		case "surface":
			clientstate.surface_select_flag = 1;
			break;
		case "dye1":
			UP.setUint32(state.select_target, 1);
			break;
		case "dye2":
			UP.setUint32(state.select_target, 2);
			break;
		case "drifter":
			UP.setUint32(state.select_target, 0);
			break;
	}
  }

  function initchecked(id) {
	switch(id) {
		case "animate":
			//if (UP.getInt32(state.n_timesteps_available) > 1) return "checked";
			if (clientstate.animate == 1) return "checked"
			else return "";
			break;
		default:
			break;
	}
  }
  function settimesteps() {
	var n = UP.getInt32(state.n_timesteps_available);
	return n.toString();
  }
 

	function buttonselect(id) {
		if (document.getElementById(id).className != "selected")
			document.getElementById(id).className = "selected";
		else
			document.getElementById(id).className = "active";

		if (id == "bbox-button") {
			clientstate.bbox ^= 1;
       		serverneedsupdate = true;
        	if (clientstate.animate) requestid = requestAnimationFrame(animateScene);
        	else requestid = requestAnimationFrame(drawScene);
		}
		if (id == "grid-button") clientstate.grid ^= 1;
		if (id == "asd-button") {///serverstate.auto_surface ^= 1;
			clientstate.auto_surface ^= 1;
			UP.setUint32(state.auto_surface, clientstate.auto_surface);
		}

		if (id == "light-button") {
		 	clientstate.light ^= 1;
		 	UP.setUint32(state.lighting_enabled, clientstate.light);
		}
		if (id == "exit-button") {
			// kill client websocket
			clientstate.connected ^= 1;
			if (!clientstate.connected) {
				UP.setUint32(state.killswitch,1);
				doSend();
				websocket.close();
			}
			else {
				// connect to server
			}
		}
  	}

	function buttonhighlight(id) {
		console.log(id + " highlighted");
	}
	$(function(){
   		$("#cutX").ionRangeSlider({
				type: "double",
				keyboard: true,
				min: -filesdv[clientstate.fileidx].getFloat32(file.half_xdim),
				max: filesdv[clientstate.fileidx].getFloat32(file.half_xdim),
				from: -filesdv[clientstate.fileidx].getFloat32(file.half_xdim),
				to: filesdv[clientstate.fileidx].getFloat32(file.half_xdim),
				step: 1,
			    prettify_separator: ",",
				prettify_enabled: true,
				onStart: function (data) {
				},
				onChange:  function (data) {
					UP.setFloat32(state.cutplane, data.from);
					UP.setFloat32(state.cutplane+4, data.to);
				},
				onFinish:  function (data) {
					UP.setFloat32(state.cutplane, data.from);
					UP.setFloat32(state.cutplane+4, data.to);
					console.log(data.to);
				},
				onUpdate:  function (data) {
					UP.setFloat32(state.cutplane, data.from);
					UP.setFloat32(state.cutplane+4, data.to);
				}
		   });
		cutx =   $("#cutX").data("ionRangeSlider");
	});



    $(function(){
    	$("#cutY").ionRangeSlider({
				type: "double",
				keyboard: true,
				min: -filesdv[clientstate.fileidx].getFloat32(file.half_ydim),
				max: filesdv[clientstate.fileidx].getFloat32(file.half_ydim),
				from: -filesdv[clientstate.fileidx].getFloat32(file.half_ydim),
				to: filesdv[clientstate.fileidx].getFloat32(file.half_ydim),
				step: 1,
			    prettify_separator: ",",
				prettify_enabled: true,
				onStart: function (data) {
				},
				onChange:  function (data) {
					UP.setFloat32(state.cutplane+8, data.from);
					UP.setFloat32(state.cutplane+12, data.to);
				},
				onFinish:  function (data) {
					UP.setFloat32(state.cutplane+8, data.from);
					UP.setFloat32(state.cutplane+12, data.to);
				},
				onUpdate:  function (data) {
					UP.setFloat32(state.cutplane+8, data.from);
					UP.setFloat32(state.cutplane+12, data.to);
				}
   		});
		cuty =   $("#cutY").data("ionRangeSlider");
	});


    $(function(){
    	$("#cutZ").ionRangeSlider({
				type: "double",
				keyboard: true,
				min: -filesdv[clientstate.fileidx].getFloat32(file.half_zdim)*num_media,
				max:  filesdv[clientstate.fileidx].getFloat32(file.half_zdim)*num_media,
				from: -filesdv[clientstate.fileidx].getFloat32(file.half_zdim)*num_media,
				to: filesdv[clientstate.fileidx].getFloat32(file.half_zdim)*num_media,
				step: 1,
			    prettify_separator: ",",
				prettify_enabled: true,
				onStart: function (data) {
				},
				onChange:  function (data) {
					UP.setFloat32(state.cutplane+16, data.to);
					UP.setFloat32(state.cutplane+20, data.from);
				},
				onFinish:  function (data) {
					UP.setFloat32(state.cutplane+16, data.to);
					UP.setFloat32(state.cutplane+20, data.from);
				},
				onUpdate:  function (data) {
					UP.setFloat32(state.cutplane+16, data.to);
					UP.setFloat32(state.cutplane+20, data.from);
				}
   		});
		cutz =   $("#cutZ").data("ionRangeSlider");
	});

    $(function(){
    	$("#clipP").ionRangeSlider({
				type: "double",
				keyboard: true,
				min: filesdv[clientstate.fileidx].getFloat32(file.near_clip_plane),
				max:  filesdv[clientstate.fileidx].getFloat32(file.far_clip_plane),
				from: UP.getFloat32(state.view_clipplane),
				to: UP.getFloat32(state.view_clipplane+4), 
				step: 1,
			    prettify_separator: ",",
				prettify_enabled: true,
				onStart: function (data) {
				},
				onChange:  function (data) {
					UP.setFloat32(state.view_clipplane, data.from);
					UP.setFloat32(state.view_clipplane+4, data.to);
				},
				onFinish:  function (data) {
					UP.setFloat32(state.view_clipplane, data.from);
					UP.setFloat32(state.view_clipplane+4, data.to);
				},
				onUpdate:  function (data) {
					UP.setFloat32(state.view_clipplane, data.from);
					UP.setFloat32(state.view_clipplane+4, data.to);
					console.log(data.to);
				}
   		});
    	clip = $("#clipP").data("ionRangeSlider");
	});

    $(function(){
    	$("#alphaM").ionRangeSlider({
				type: "single",
				keyboard: true,
				min: 0.0,
				max: 1.0,
				from: filesdv[clientstate.fileidx].getFloat32(file.init_alpha_m),
				step: 0.01,
			    prettify_separator: ",",
				prettify_enabled: true,
				onStart: function (data) {
				},
				onChange:  function (data) {
					UP.setFloat32(state.alpha_m, data.from);
				},
				onFinish:  function (data) {
					UP.setFloat32(state.alpha_m, data.from);
				},
				onUpdate:  function (data) {
					UP.setFloat32(state.alpha_m, data.from);
				}
   		});
		alpham =   $("#alphaM").data("ionRangeSlider");
	});

    $(function(){
    	$("#alphaE").ionRangeSlider({
				type: "single",
				keyboard: true,
				min: 0,
				max: 4.0,
				from: filesdv[clientstate.fileidx].getFloat32(file.init_alpha_e),
				step: 0.01,
			    prettify_separator: ",",
				prettify_enabled: true,
				onStart: function (data) {
				},
				onChange: function (data) {
					UP.setFloat32(state.alpha_e, data.from);
				},
				onFinish: function (data) {
					UP.setFloat32(state.alpha_e, data.from);
				},
				onUpdate: function (data) {
					UP.setFloat32(state.alpha_e, data.from);
				}
   		});
		alphae =   $("#alphaE").data("ionRangeSlider");
	});

    $(function(){
    	$("#deltaS").ionRangeSlider({
				type: "single",
				keyboard: true,
				prettify_enabled: true,
				min: 0.00,
				max: 1.00,
				from: 0.76,
				step: 0.01,
			    prettify_separator: ",",
				prettify_enabled: true,
				onStart: function (data) {
				},
				onChange:  function (data) {
					var dens = 1.0/Math.exp(14.0 * data.from);
					UP.setFloat32(state.deltasample, dens);
				},
				onFinish:  function (data) {
					var dens = 1.0/Math.exp(14.0 * data.from);
					UP.setFloat32(state.deltasample, dens);
				},
				onUpdate:  function (data) {
					var dens = 1.0/Math.exp(14.0 * data.from);
					UP.setFloat32(state.deltasample, dens);
				}
   		});
		deltas =   $("#deltaS").data("ionRangeSlider");
	});

    $(function(){
    	$("#pointSz").ionRangeSlider({
				type: "single",
				keyboard: true,
				min: 0,
				max: 6,
				from: UP.getUint32(state.pointsize),
				step: 1,
			    prettify_separator: ",",
				prettify_enabled: true,
				onStart: function (data) {
				},
				onChange:  function (data) {
					UP.setUint32(state.pointsize, data.from);
					UP.setUint32(state.display, 1);
					UP.setUint32(state.display+4, 1);
					UP.setUint32(state.display+8, 1);
				},
				onFinish:  function (data) {
					UP.setUint32(state.pointsize, data.from);
					UP.setUint32(state.display, 1);
					UP.setUint32(state.display+4, 1);
					UP.setUint32(state.display+8, 1);
				},
				onUpdate:  function (data) {
					UP.setUint32(state.pointsize, data.from);
					UP.setUint32(state.display, 1);
					UP.setUint32(state.display+4, 1);
					UP.setUint32(state.display+8, 1);
				}
   		});
		pointsz =   $("#pointSz").data("ionRangeSlider");
	});

	var level = filesdv[clientstate.fileidx].getFloat64(file.processed_maxval);
    $(function(){
    	$("#pointLevel").ionRangeSlider({
				type: "single",
				keyboard: true,
				min: filesdv[clientstate.fileidx].getFloat64(file.processed_minval),
				max: level,
				from: filesdv[clientstate.fileidx].getFloat32(file.init_level),
				step: 1,
			    prettify_separator: ",",
				prettify_enabled: true,
			    prettify:	function (num) {
								var m = num
								return m.toExponential(2);
							},
				onStart: function (data) {
					from: UP.getFloat64(state.levelval);
				},
				onChange:  function (data) {
					var log_map = filesdv[clientstate.fileidx].getUint32(file.logarithmic_colormap);
					if (log_map) {
						var myval = (data.from) << 20;
						UP.setFloat64(state.levelval, myval);
					}
					else {
						var maxval = filesdv[clientstate.fileidx].getFloat64(file.processed_maxval);
                		var minval = filesdv[clientstate.fileidx].getFloat64(file.processed_minval);
                		UP.setFloat64(state.levelval, data.from);
					}
				},
				onFinish:  function (data) {
					var log_map = filesdv[clientstate.fileidx].getUint32(file.logarithmic_colormap);
					if (log_map) {
						var myval = (data.from) << 20;
						UP.setFloat64(state.levelval, myval);
					}
					else {
						var maxval = filesdv[clientstate.fileidx].getFloat64(file.processed_maxval);
                		var minval = filesdv[clientstate.fileidx].getFloat64(file.processed_minval);
                		UP.setFloat64(state.levelval, data.from);
					}
				},
				onUpdate:  function (data) {
					var log_map = filesdv[clientstate.fileidx].getUint32(file.logarithmic_colormap);
					if (log_map) {
						var myval = (data.from) << 20;
						UP.setFloat64(state.levelval, myval);
					}
					else {
						var maxval = filesdv[clientstate.fileidx].getFloat64(file.processed_maxval);
                		var minval = filesdv[clientstate.fileidx].getFloat64(file.processed_minval);
                		UP.setFloat64(state.levelval, data.from);
					}
				}
   		});
		pointlevel =   $("#pointLevel").data("ionRangeSlider");
	});

    $(function(){
	 	$("#timeStep").ionRangeSlider({
				type: "single",
				keyboard: true,
				min: 0,
				max: filesdv[clientstate.fileidx].getUint32(file.n_timesteps) - 1,
				from: 0,
				step: 1,
				onStart: function (data) {
				},
				onChange:  function (data) {
					UP.setInt32(state.timestep, data.from);
				},
				onFinish:  function (data) {
					UP.setInt32(state.timestep, data.from);
				},
				onUpdate:  function (data) {
					UP.setInt32(state.timestep, data.from);
				}
	   });
		timesteps =   $("#timeStep").data("ionRangeSlider");
	});

	// initialize the gui
/*
	function initGUI() {

		cutx.update({
           min: -filesdv[clientstate.fileidx].getFloat32(file.half_xdim),
           max: filesdv[clientstate.fileidx].getFloat32(file.half_xdim),
           from: -filesdv[clientstate.fileidx].getFloat32(file.half_xdim),
           to: filesdv[clientstate.fileidx].getFloat32(file.half_xdim),
		});
		cuty.update({
           min: -filesdv[clientstate.fileidx].getFloat32(file.half_ydim),
           max: filesdv[clientstate.fileidx].getFloat32(file.half_ydim),
           from: -filesdv[clientstate.fileidx].getFloat32(file.half_ydim),
           to: filesdv[clientstate.fileidx].getFloat32(file.half_ydim),
		});
		cutz.update({
           min: -filesdv[clientstate.fileidx].getFloat32(file.half_zdim),
           max: filesdv[clientstate.fileidx].getFloat32(file.half_zdim),
           from: -filesdv[clientstate.fileidx].getFloat32(file.half_zdim),
           to: filesdv[clientstate.fileidx].getFloat32(file.half_zdim),
		});	
		clip.update({
			min: filesdv[clientstate.fileidx].getFloat32(file.near_clip_plane),
			max:  filesdv[clientstate.fileidx].getFloat32(file.far_clip_plane),
			from: UP.getFloat32(state.view_clipplane),
			to: UP.getFloat32(state.view_clipplane+4), 
		});

		alpham.update({
            from: INITIAL_ALPHA_MULT,
		});

		alphae.update({
            from: INITIAL_ALPHA_EXP,
		});

		pointsz.update({
            from: UP.getUint32(state.pointsize),
		});	

		pointlevel.update({
			min: filesdv[clientstate.fileidx].getFloat64(file.processed_minval),
			max: filesdv[clientstate.fileidx].getFloat64(file.processed_maxval),
            from: UP.getFloat64(state.levelval),
		});	
				
		timesteps.update({
			max: filesdv[clientstate.fileidx].getUint32(file.timesteps),
		});

		clientstate.animate = (filesdv[clientstate.fileidx].getUint32(file.timesteps) > 1) ? 1: 0;
		document.getElementById('animate').checked =  ((clientstate.animate === 1) ? "checked" : "");
	}
*/


// iterate through the list
	function  buildtypelist() {
		var dropDown = document.getElementById("selecttype");
		for (var i=0; i<NUM_TYPES; i++) {
			// create a new element
			var optionItem = document.createElement("option");

			var type = types[i];

			// set the value 
			optionItem.value=i;
			optionItem.text= type;	
			if (i === clientstate.typeidx) optionItem.selected=true;
			switch(i) {
				case 0: optionItem.disabled = false;
						optionItem.selected = true;
						break;
				case 1: optionItem.disabled = false;
						optionItem.selected = false
						break;
			}

   			// append the item to the list
   			dropDown.appendChild(optionItem);
		}
	}
// iterate through the list
	function  builddyelist() {
		var dropDown = document.getElementById("dyetype");
		for (var i=0; i<NUM_DYES; i++) {
			// create a new element
			var optionItem = document.createElement("option");

			var type = dyes[i];

			// set the value 
			optionItem.value=i;
			optionItem.text= type;	
			if (i === clientstate.dyeidx) optionItem.selected=true;
			switch(i) {
				case 0: optionItem.disabled = false;
						optionItem.selected = true;
						break;
				case 1: optionItem.disabled = false;
						optionItem.selected = false
						break;
				case 2: optionItem.disabled = false;
						optionItem.selected = false
						break;
				break;
			}

   			// append the item to the list
   			dropDown.appendChild(optionItem);
		}
	}
// iterate through the list
	function  buildmodellist() {
		var dropDown = document.getElementById("mymodel");
		for (var i=0; i<NUM_FILEPACKETS; i++) {
			// create a new element
			var optionItem = document.createElement("option");

			var model = models[i];

			// set the value 
			optionItem.value=i;
			optionItem.text= model;	
			if (i === clientstate.fileidx) optionItem.selected=true;
			switch(i) {
				case 0: optionItem.disabled = false;
						break;
				case 1: optionItem.disabled = false;
						break;
				case 2: optionItem.disabled = false;
						break;
				case 3: optionItem.disabled = false;
						break;
				case 4: optionItem.disabled = true;
				case 5: optionItem.disabled = true;
				case 6: optionItem.disabled = true;
				case 7: optionItem.disabled = true;
						break;
				case 8: optionItem.disabled = false;
						break;
				case 9:  optionItem.disabled = true;
				case 10: optionItem.disabled = true;
				case 11: optionItem.disabled = true;
				case 12: optionItem.disabled = true;
						break;
				case 13: optionItem.disabled = false;
						 break;
				case 14: optionItem.disabled = true;
						 break;
				case 15: optionItem.disabled = false; 
				case 16: optionItem.disabled = false;
				case 17: optionItem.disabled = false;
				case 18: optionItem.disabled = false;
				case 19: optionItem.disabled = false;
				case 20: optionItem.disabled = false;
				case 21: optionItem.disabled = false;
				case 22: optionItem.disabled = false;
				case 23: optionItem.disabled = false;
				case 24: optionItem.disabled = false;
				case 25: optionItem.disabled = false;
				case 26: optionItem.disabled = false;
				case 27: optionItem.disabled = false;
				case 28: optionItem.disabled = false;
						 break;
				break;
			}

   			// append the item to the list
   			dropDown.appendChild(optionItem);
		}
	}

	function selectmodel(id) {
		var dropDown = document.getElementById(id);
		var selected = dropDown.selectedIndex;
		clientstate.fileidx = selected;
		clientstate.changed = true;
		serverneedsupdate = true;
		initStatePacket();
		initBuffers();
		initCamera();
		//initGUI();
		UP.setUint32(state.killswitch, 2);
		doSend(UP);
		UP.setUint32(state.killswitch, 0);
		UP.setUint32(state.vpchange, 0);
//		serverneedsupdate = true;
      	if (clientstate.animate === 1) {
            cancelAnimationFrame(requestid);
			serverneedsupdate = true;
            requestid = requestAnimationFrame(animateScene);
        }
        else {
            cancelAnimationFrame(requestid);
            requestid = requestAnimationFrame(drawScene);
        }
	}
	function selectdye(id) {
		var dropDown = document.getElementById(id);
		var selected = dropDown.selectedIndex;
		clientstate.dyeidx = selected;
		clientstate.changed = true;
		serverneedsupdate = true;
		initStatePacket();
		initBuffers();
		initCamera();
		//initGUI();
		UP.setUint32(state.killswitch, 2);
		doSend(UP);
		UP.setUint32(state.killswitch, 0);
		UP.setUint32(state.vpchange, 0);
//		serverneedsupdate = true;
      	if (clientstate.animate === 1) {
            cancelAnimationFrame(requestid);
			serverneedsupdate = true;
            requestid = requestAnimationFrame(animateScene);
        }
        else {
            cancelAnimationFrame(requestid);
            requestid = requestAnimationFrame(drawScene);
        }
	}


	function selecttype(id) {
		var dropDown = document.getElementById(id);
		var selected = dropDown.selectedIndex;
		clientstate.typeidx = selected;
		clientstate.changed = true;
		serverneedsupdate = true;
		initStatePacket();
		initBuffers();
		initCamera();
		//initGUI();
		UP.setUint32(state.killswitch, 2);
		doSend(UP);
		UP.setUint32(state.killswitch, 0);
		UP.setUint32(state.vpchange, 0);
//		serverneedsupdate = true;
      	if (clientstate.animate === 1) {
            cancelAnimationFrame(requestid);
			serverneedsupdate = true;
            requestid = requestAnimationFrame(animateScene);
        }
        else {
            cancelAnimationFrame(requestid);
            requestid = requestAnimationFrame(drawScene);
        }
	}
