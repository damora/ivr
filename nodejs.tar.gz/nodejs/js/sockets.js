
//var wsUri = "ws://9.2.186.134:8888";
//var wsUri = "ws://9.2.132.200:8888";
//var wsUri = "ws://9.2.132.209:8888";
//var wsUri = "ws://9.2.133.156:8888";
//var wsUri = "ws://9.2.132.202:8888";
//var wsUri = "ws://9.2.133.163:8888";
var wsUri = "ws://9.2.133.169:8888";
var websocket;
var disconnected = new Image();

function websocketinit() {
	trace("websocketinit executed");
   	initWebSocket();
}

function initWebSocket() {
   websocket = new WebSocket(wsUri);
   websocket.binaryType = "arraybuffer";
   websocket.onopen = function(evt) { onOpen(evt); };
   websocket.onclose = function(evt) { onClose(evt); };
   websocket.onmessage = function(evt) { onMessage(evt); };
   websocket.onerror = function(evt) { onError(evt); };
}

function onOpen(evt) {
   trace("onOpen");
	showimage("../images/connected.png", "",39, 30);
	// this is a hack so I can get image now and later show when I disconnect I don't have to wait for 
	// image to be transferred from server
	disconnected.src = "../images/disconnected.png";
}

function onClose(evt) {
	trace("onClose");
 	showimage(disconnected.src, "",39, 30);
}


function appendBuffer(buffer1, buffer2, tilebuffer_offset) {
   buffer1.set(new Uint8Array(buffer2), tilebuffer_offset);
   return buffer1;
} 

var tilesize = 0;
var tileidx = -1;
var bytesremaining = 0;
var buffer ;
var len=0;
var dvevt;
var word0;
var wordA;
var wordB;
var messagebuffer_offset;
var tilebuffer_offset;


function onMessage(evt) {
   trace("onMessage");
	
   if (evt.data instanceof ArrayBuffer) {
     len  = evt.data.byteLength;
     dvevt = new DataView(evt.data);

    messagebuffer_offset = 0;
	if (bytesremaining) {
         if (bytesremaining <= len) { 
           // shove "bytesremaining" into current tile, and put a ribbon on it, because it's done.
		 	buffer  = appendBuffer(buffer, evt.data.slice(messagebuffer_offset,messagebuffer_offset+bytesremaining), tilebuffer_offset);
			tiles[tileidx] = buffer;
			nulltiles[tileidx] = 0;
			messagebuffer_offset += bytesremaining;
			tilebuffer_offset += bytesremaining;
			//bytesremaining -= bytesremaining;
			bytesremaining = 0;
		}
       	else {
            // shove "len" bytes into current tile
         	buffer  = appendBuffer(buffer, evt.data.slice(messagebuffer_offset,len), tilebuffer_offset);
         	messagebuffer_offset += len;
         	tilebuffer_offset += len;
         	bytesremaining -= len;
         }
	}
    while (messagebuffer_offset < len) {
		// here we know we are at a new "index/size" word and we will process one tile or one "done" message
        // per loop iteration.  Note that if "bytesremaining" was nonzero at this point, it would be an error.
		
      	word0 = dvevt.getUint32(messagebuffer_offset, true);
      	tileidx = word0 >> 24;
      	messagebuffer_offset += 4;
        if (tileidx >= ntiles) {
		   n_timesteps_read  = word0 & 0x00ffffff;
           clientrecvdtiles++;
        }
        else {
           	bytesremaining = tilesize = (word0 & 0x00ffffff);
				if (bytesremaining <= (len-messagebuffer_offset)) { 
             	// shove "bytesremaining" bytes into current tile, and put a ribbon on it
					buffer = new Uint8Array(evt.data.slice(messagebuffer_offset, messagebuffer_offset+tilesize));
					tiles[tileidx] = buffer;
            		nulltiles[tileidx] = 0;
              		messagebuffer_offset += bytesremaining;
               		bytesremaining -= bytesremaining;
            	}
            	else {
               		// shove "len - messagebuffer_offset" bytes into current tile
            		// set up new tile with the current tileidx value
					buffer = new Uint8Array(tilesize);
					tilebuffer_offset = 0;
					buffer = appendBuffer(buffer, evt.data.slice(messagebuffer_offset,len), tilebuffer_offset);
               		bytesremaining -= (len - messagebuffer_offset);
               		tilebuffer_offset += (len - messagebuffer_offset);
               		messagebuffer_offset += (len - messagebuffer_offset);
            	}
         	}
      	}
   	}
   	else {
      	console.log("Error! evt.data instanceof ArrayBuffer was FALSE!");
      	writeToScreen(('<span style="color: blue;">RECVD: ' + evt.data.toString('utf8') + '</span>'), '#ff4040' );
   	}
}

function onError(evt) {
	if(websocket.readyState === 0){
    	//do nothing
    }
	else if (websocket.readyState !=1){
   		//fallback
   		setInterval(poll, 50);
	}
   writeToScreen(('<span style="color: red;">ERROR:</span> ' + evt.data), '#ff4040');
}

function doSend(message) {
	trace("doSend", "readyState=",websocket.readyState, "serverneedsupdate=", serverneedsupdate);
	if (websocket.readyState === 1 && serverneedsupdate) {
		//printServerState();
		websocket.send(message);
	}
}

function writeToScreen(message, color) {
   document.getElementById('status').style.backgroundColor = color;
   document.getElementById('status').textContent = message;
}

function showimage(src, alt, width, height) {
	document.getElementById('status').src = src;
	document.getElementById('status').width = width;
	document.getElementById('status').height = height;
	document.getElementById('status').alt = alt;
}

window.addEventListener('load', websocketinit, false);

