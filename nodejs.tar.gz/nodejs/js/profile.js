var start;
var stop;
var framenum;
var elapsed;
var avg;

function TIME(t) {
	t = (new Date()).getTime();
	return t;
}
function RESET_TIME() {
	start = 0;
	stop = 0;
	framenum = 0;
	elapsed = 0.0; 
	avg= 0.0;
}

function F_RATE(fn, totalsec) {
	(fn)/(((totalsec <= 0) ? 1.0:totalsec));
}

function PERFORMANCE(str, stp, fnum, elap, a)
{                                           
	var e;                                 
	elap += (stp-str);                    
	e = elap * nsec_per_sec;             
	a = F_RATE(++fnum, e);              
	a *= convfac;                      
	console.log("dciv %e fps", a);    
}



