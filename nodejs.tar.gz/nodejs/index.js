var express = require('express');
var net = require('net');
var WebSocketServer = require('ws').Server;
//var server = require('./js/server.js');
//var router = require('./js/router.js');
//server.start(router.route);
//require('./js/statedata.js');
var httpport = 8000;
var wsport = 8888;
//var tcpport = 1850;
var tcpport = 1870;
//var host = "9.2.132.200";
//var host = "9.2.132.209";
//var host = "9.2.133.147";
//var host = "9.2.133.156";
//var host="172.16.5.110";
//var host = "9.2.133.163";
var host = "9.2.133.169";
var tcpsocket;
var serverready = 0;
var dirname = "./";
var websocket;
var sendcounter = 0;


var app = express();
app.use(express.static(dirname));
console.log("HTTP server listening on port: " + httpport);
app.listen(httpport);
 

    var server = new net.createServer(function(socket) {
		console.log("createServer:,socket connected");
		tcpsocket = socket;
		serverready  = 1;

        socket.on('data', function(message) {
            console.log("RECVD: %d image bytes from tcp client", message.length);
            websocket.send(message);
        });

        socket.on('end', function(message) {
            console.log("TCP socket closed", message);
			websocket.send(message);
        });

        socket.on('error', function() {
            console.log("TCP connection error", arguments);
		});
 		
	}).listen(tcpport);
    console.log('TCP listening on host %s, port = %d', host, tcpport);

	var wss = new WebSocketServer({ port: wsport });
	console.log("WebSocket listening on port %d", wsport);
	

	wss.on("connection", function(ws) {
		 console.log("WebSocket client connected");
		 websocket = ws;
			// WebSocket handler functions
			websocket.on('message', function(message) {
				console.log("RECVD: message from WS client: %d bytes and serverready=%d", message.length, serverready);
				switch (serverready) {
					case 0: console.log("SENT0: No bytes sent to TCP client");
							break;
					case 1: console.log("SENT1: Initial message sent to TCP client");
							tcpsocket.write(message);
							tcpsocket.write(message);
							serverready = 2;
							break;
					case 2: console.log("SENT2: len=%d  bytes to TCP client", message.length);
							tcpsocket.write(message);
							break;
					default: break;
				}
				return;
			});
			websocket.on("close", function(ws) {
					console.log("WebSocket closed:%d, %d", reason, code);
					// close backend connection
					ws.end();
			});
	});
